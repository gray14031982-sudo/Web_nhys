import React from 'react';
import { 
  GraduationCap, 
  Sparkles, 
  Calculator, 
  Download, 
  PlusCircle, 
  BookOpen,
  Settings,
  Bell,
  School
} from 'lucide-react';
import { GpaStandard, GpaStats } from '../types/curriculum';

interface HeaderProps {
  stats: GpaStats;
  gpaStandard: GpaStandard;
  activeTab: 'roadmap' | 'table' | 'simulator' | 'ai-advisor' | 'settings';
  setActiveTab: (tab: 'roadmap' | 'table' | 'simulator' | 'ai-advisor' | 'settings') => void;
  onOpenAddModal: () => void;
  onExportCsv: () => void;
  unreadNotificationsCount: number;
  onOpenNotifications: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  stats,
  gpaStandard,
  activeTab,
  setActiveTab,
  onOpenAddModal,
  onExportCsv,
  unreadNotificationsCount,
  onOpenNotifications,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-900 text-white border-b border-slate-800 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between py-3 gap-3">
          
          {/* Logo & Student Title */}
          <div className="flex items-center space-x-3.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-indigo-600 flex items-center justify-center shadow-inner shrink-0">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-lg font-bold tracking-tight text-white">Finance Scholar</h1>
                <span className="text-[11px] font-bold tracking-wide uppercase px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center space-x-1">
                  <School className="w-3 h-3 mr-0.5" />
                  <span>UFM · TCNH</span>
                </span>
                <span className="hidden sm:inline-block text-[10px] font-medium text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded border border-slate-700">
                  {gpaStandard === 'UFM' ? 'Chuẩn UFM (QĐ 3279)' : 'Chuẩn Bộ GD&ĐT'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Trường Đại học Tài chính - Marketing · Đang học Học kỳ 4 (Năm 2)
              </p>
            </div>
          </div>

          {/* Quick Nav Tabs */}
          <div className="flex items-center bg-slate-800/90 p-1 rounded-xl border border-slate-700/70 overflow-x-auto text-xs font-medium">
            <button
              onClick={() => setActiveTab('roadmap')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg transition-all whitespace-nowrap ${
                activeTab === 'roadmap'
                  ? 'bg-indigo-600 text-white shadow-sm font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Lộ Trình & Thẻ</span>
            </button>

            <button
              onClick={() => setActiveTab('table')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg transition-all whitespace-nowrap ${
                activeTab === 'table'
                  ? 'bg-indigo-600 text-white shadow-sm font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <span>Bảng Sheet</span>
            </button>

            <button
              onClick={() => setActiveTab('simulator')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg transition-all whitespace-nowrap ${
                activeTab === 'simulator'
                  ? 'bg-indigo-600 text-white shadow-sm font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <Calculator className="w-3.5 h-3.5 text-amber-400" />
              <span>Dự Báo GPA</span>
            </button>

            <button
              onClick={() => setActiveTab('ai-advisor')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg transition-all whitespace-nowrap ${
                activeTab === 'ai-advisor'
                  ? 'bg-indigo-600 text-white shadow-sm font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>Cố Vấn AI</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg transition-all whitespace-nowrap ${
                activeTab === 'settings'
                  ? 'bg-indigo-600 text-white shadow-sm font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <Settings className="w-3.5 h-3.5 text-slate-300" />
              <span>Cài Đặt & Dữ Liệu</span>
            </button>
          </div>

          {/* Action Buttons & Notification Bell */}
          <div className="flex items-center space-x-2 shrink-0">
            {/* Notification Bell */}
            <button
              onClick={onOpenNotifications}
              className="relative p-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors border border-slate-700"
              title="Xem thông báo"
            >
              <Bell className="w-4 h-4" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-[10px] font-bold text-white flex items-center justify-center animate-pulse">
                  {unreadNotificationsCount}
                </span>
              )}
            </button>

            <button
              onClick={onOpenAddModal}
              className="flex items-center space-x-1.5 px-3 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors shadow-sm"
              title="Thêm môn học mới"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>Thêm Môn</span>
            </button>

            <button
              onClick={onExportCsv}
              className="flex items-center space-x-1.5 px-2.5 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors border border-slate-700"
              title="Xuất file CSV chuẩn Excel"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Xuất CSV</span>
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
