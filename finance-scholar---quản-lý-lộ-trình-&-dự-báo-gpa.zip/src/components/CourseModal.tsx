import React, { useState, useEffect } from 'react';
import { X, Check, Link as LinkIcon, FileText } from 'lucide-react';
import { Course, CourseDifficulty, CourseLanguage, CourseStatus, SemesterId, SemesterInfo } from '../types/curriculum';
import { SEMESTER_LIST } from '../data/initialCourses';

interface CourseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (course: Course) => void;
  initialCourse?: Course | null;
  availableSemesters?: SemesterInfo[];
}

export const CourseModal: React.FC<CourseModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialCourse,
  availableSemesters = SEMESTER_LIST,
}) => {
  const [semester, setSemester] = useState<SemesterId>('Năm 2 - HK 4');
  const [name, setName] = useState('');
  const [credits, setCredits] = useState(3);
  const [language, setLanguage] = useState<CourseLanguage>('Tiếng Việt');
  const [totalSessions, setTotalSessions] = useState(15);
  const [attendedSessions, setAttendedSessions] = useState(0);
  const [targetScore, setTargetScore] = useState<string>('');
  const [actualScore, setActualScore] = useState<string>('');
  const [status, setStatus] = useState<CourseStatus>('Đang học');
  const [difficulty, setDifficulty] = useState<CourseDifficulty>('Trung bình');
  const [examFormat, setExamFormat] = useState('');
  const [documents, setDocuments] = useState('');
  const [documentUrl, setDocumentUrl] = useState('');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (initialCourse) {
      setSemester(initialCourse.semester);
      setName(initialCourse.name);
      setCredits(initialCourse.credits);
      setLanguage(initialCourse.language);
      setTotalSessions(initialCourse.totalSessions);
      setAttendedSessions(initialCourse.attendedSessions);
      setTargetScore(initialCourse.targetScore !== null ? String(initialCourse.targetScore) : '');
      setActualScore(initialCourse.actualScore !== null ? String(initialCourse.actualScore) : '');
      setStatus(initialCourse.status);
      setDifficulty(initialCourse.difficulty);
      setExamFormat(initialCourse.examFormat);
      setDocuments(initialCourse.documents || '');
      setDocumentUrl(initialCourse.documentUrl || '');
      setNotes(initialCourse.notes || '');
    } else {
      setSemester('Năm 2 - HK 4');
      setName('');
      setCredits(3);
      setLanguage('Tiếng Việt');
      setTotalSessions(15);
      setAttendedSessions(0);
      setTargetScore('');
      setActualScore('');
      setStatus('Đang học');
      setDifficulty('Trung bình');
      setExamFormat('');
      setDocuments('');
      setDocumentUrl('');
      setNotes('');
    }
  }, [initialCourse, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const parsedTarget = targetScore.trim() !== '' ? parseFloat(targetScore.replace(',', '.')) : null;
    const parsedActual = actualScore.trim() !== '' ? parseFloat(actualScore.replace(',', '.')) : null;

    const updatedCourse: Course = {
      id: initialCourse ? initialCourse.id : `course_${Date.now()}`,
      semester,
      name: name.trim(),
      credits: Number(credits) || 3,
      language,
      totalSessions: Number(totalSessions) || 15,
      attendedSessions: Number(attendedSessions) || 0,
      targetScore: parsedTarget !== null && !isNaN(parsedTarget) ? parsedTarget : null,
      actualScore: parsedActual !== null && !isNaN(parsedActual) ? parsedActual : null,
      status,
      difficulty,
      examFormat: examFormat.trim(),
      documents: documents.trim(),
      documentUrl: documentUrl.trim(),
      notes: notes.trim(),
      simulatedScore: initialCourse?.simulatedScore,
    };

    onSave(updatedCourse);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-lg w-full overflow-hidden max-h-[90vh] flex flex-col">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div>
            <h3 className="font-bold text-slate-900 text-base">
              {initialCourse ? 'Chỉnh Sửa Học Phần' : 'Thêm Học Phần Mới'}
            </h3>
            <p className="text-[11px] text-slate-500">Chương trình Cử nhân Tài chính - Ngân hàng UFM</p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 text-xs">
          
          {/* Tên học phần */}
          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Tên học phần <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="VD: Thị trường tài chính, Tài chính doanh nghiệp..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
            />
          </div>

          {/* Học kỳ & Số tín chỉ */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Học kỳ</label>
              <select
                value={semester}
                onChange={(e) => setSemester(e.target.value as SemesterId)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 cursor-pointer"
              >
                {availableSemesters.map((sem) => (
                  <option key={sem.id} value={sem.id}>
                    {sem.id}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Số tín chỉ</label>
              <input
                type="number"
                min="1"
                max="15"
                value={credits}
                onChange={(e) => setCredits(parseInt(e.target.value) || 3)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
              />
            </div>
          </div>

          {/* Ngôn ngữ & Trạng thái */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Ngôn ngữ giảng dạy</label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as CourseLanguage)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 cursor-pointer"
              >
                <option value="Tiếng Việt">Tiếng Việt (TV)</option>
                <option value="Tiếng Anh">Tiếng Anh (TA)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Trạng thái học</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as CourseStatus)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 cursor-pointer"
              >
                <option value="Đang học">Đang học (HK hiện tại)</option>
                <option value="Đã học">Đã hoàn thành</option>
                <option value="Chưa học">Chưa học</option>
              </select>
            </div>
          </div>

          {/* Buổi học */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Số buổi đã học</label>
              <input
                type="number"
                min="0"
                value={attendedSessions}
                onChange={(e) => setAttendedSessions(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Tổng số buổi</label>
              <input
                type="number"
                min="1"
                value={totalSessions}
                onChange={(e) => setTotalSessions(parseInt(e.target.value) || 15)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
              />
            </div>
          </div>

          {/* Điểm mục tiêu vs Điểm thực tế */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Điểm mục tiêu (Thang 10)</label>
              <input
                type="text"
                value={targetScore}
                onChange={(e) => setTargetScore(e.target.value)}
                placeholder="VD: 8.5 hoặc 8,0"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Điểm thực tế (Thang 10)</label>
              <input
                type="text"
                value={actualScore}
                onChange={(e) => setActualScore(e.target.value)}
                placeholder="VD: 8.2 hoặc bỏ trống nếu chưa có"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
              />
            </div>
          </div>

          {/* Độ khó & Hình thức thi */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Mức độ khó</label>
              <select
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value as CourseDifficulty)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 cursor-pointer"
              >
                <option value="Dễ">Dễ</option>
                <option value="Trung bình">Trung bình</option>
                <option value="Khó">Khó</option>
              </select>
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Hình thức thi</label>
              <input
                type="text"
                value={examFormat}
                onChange={(e) => setExamFormat(e.target.value)}
                placeholder="VD: Đề mở + TN, Tiểu luận, Đề đóng + TL..."
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
              />
            </div>
          </div>

          {/* Tên tài liệu & Link URL tài liệu */}
          <div className="space-y-2 bg-indigo-50/40 p-3 rounded-xl border border-indigo-100">
            <div>
              <label className="block font-bold text-indigo-900 mb-1 flex items-center space-x-1">
                <FileText className="w-3.5 h-3.5 text-indigo-600" />
                <span>Tên tài liệu / Ghi chú thư mục</span>
              </label>
              <input
                type="text"
                value={documents}
                onChange={(e) => setDocuments(e.target.value)}
                placeholder="VD: GIẢI ĐÁP TA TRONG KD, PSH + Drive tôi..."
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
              />
            </div>

            <div>
              <label className="block font-bold text-indigo-900 mb-1 flex items-center space-x-1">
                <LinkIcon className="w-3.5 h-3.5 text-indigo-600" />
                <span>Đường dẫn liên kết (Link Google Drive / OneDrive / Web)</span>
              </label>
              <input
                type="url"
                value={documentUrl}
                onChange={(e) => setDocumentUrl(e.target.value)}
                placeholder="https://drive.google.com/..."
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 font-mono text-[11px]"
              />
              <span className="text-[10px] text-indigo-600/80 mt-1 block">
                * Khi nhập liên kết ở đây, tên tài liệu trên thẻ sẽ tự động trở thành nút bấm để mở tài liệu ngay lập tức.
              </span>
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Ghi chú cá nhân</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Mẹo học, lưu ý của giảng viên, phân công nhóm..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
            />
          </div>

          {/* Actions */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg font-medium transition-colors"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold transition-colors flex items-center space-x-1.5 shadow-xs"
            >
              <Check className="w-4 h-4" />
              <span>{initialCourse ? 'Lưu Thay Đổi' : 'Tạo Môn Học'}</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
