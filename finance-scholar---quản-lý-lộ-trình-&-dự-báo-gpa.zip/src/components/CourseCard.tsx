import React from 'react';
import { 
  FileText, 
  Edit3, 
  Trash2, 
  Plus, 
  Minus, 
  ExternalLink, 
  CheckCircle2,
  Clock,
  CircleDashed
} from 'lucide-react';
import { Course, GpaStandard } from '../types/curriculum';
import { scoreToLetter, scoreToScale4 } from '../utils/gradeCalculations';
import { DocumentLink } from './DocumentLink';

interface CourseCardProps {
  course: Course;
  gpaStandard?: GpaStandard;
  onEdit: (course: Course) => void;
  onDelete: (courseId: string) => void;
  onUpdateAttendance: (courseId: string, delta: number) => void;
}

export const CourseCard: React.FC<CourseCardProps> = ({
  course,
  gpaStandard = 'UFM',
  onEdit,
  onDelete,
  onUpdateAttendance,
}) => {
  const isCompleted = course.status === 'Đã học';
  const isInProgress = course.status === 'Đang học';
  const isUpcoming = course.status === 'Chưa học';

  const progressPercent = course.totalSessions > 0
    ? Math.min(100, Math.round((course.attendedSessions / course.totalSessions) * 100))
    : 0;

  // Score comparison
  const diffScore = 
    course.actualScore !== null && course.targetScore !== null 
      ? Number((course.actualScore - course.targetScore).toFixed(1)) 
      : null;

  return (
    <div className={`bg-white rounded-xl border transition-all p-4 flex flex-col justify-between hover:shadow-sm ${
      isInProgress 
        ? 'border-amber-300 ring-1 ring-amber-300/40 bg-gradient-to-b from-amber-50/20 to-white' 
        : isCompleted 
        ? 'border-slate-200/90' 
        : 'border-slate-200/70 bg-slate-50/30'
    }`}>
      <div>
        {/* Unboxed Metadata Kicker (Anti-slop compliant) */}
        <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
          <div className="flex items-center space-x-1.5 font-medium">
            <span className="text-slate-700 font-semibold">{course.semester}</span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span>{course.credits} Tín chỉ</span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span className={course.language === 'Tiếng Anh' ? 'text-indigo-600 font-semibold' : 'text-slate-600'}>
              {course.language}
            </span>
          </div>

          <div className="flex items-center space-x-1 text-[11px] font-semibold">
            {isCompleted && (
              <span className="text-emerald-700 flex items-center">
                <CheckCircle2 className="w-3.5 h-3.5 mr-0.5" />
                Đã học
              </span>
            )}
            {isInProgress && (
              <span className="text-amber-700 flex items-center font-bold">
                <Clock className="w-3.5 h-3.5 mr-0.5" />
                Đang học
              </span>
            )}
            {isUpcoming && (
              <span className="text-slate-400 flex items-center">
                <CircleDashed className="w-3.5 h-3.5 mr-0.5" />
                Chưa học
              </span>
            )}
          </div>
        </div>

        {/* Title */}
        <h3 className="text-base font-bold text-slate-900 tracking-tight leading-snug">
          {course.name}
        </h3>

        {/* Difficulty & Exam Format text metadata */}
        <div className="mt-1.5 flex flex-wrap items-center gap-x-2 text-xs text-slate-500">
          <span className="flex items-center">
            Độ khó:{' '}
            <strong className={`ml-1 font-medium ${
              course.difficulty === 'Khó' ? 'text-rose-600' :
              course.difficulty === 'Trung bình' ? 'text-amber-600' : 'text-emerald-600'
            }`}>
              {course.difficulty}
            </strong>
          </span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span>Thi: <strong className="text-slate-700 font-medium">{course.examFormat || 'Chưa cập nhật'}</strong></span>
        </div>

        {/* Attendance section */}
        <div className="mt-3.5 pt-3 border-t border-slate-100">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-slate-500">
              Buổi học: <strong className="text-slate-800">{course.attendedSessions}/{course.totalSessions}</strong> ({progressPercent}%)
            </span>

            {/* Quick +/- buttons for in-progress courses */}
            {isInProgress && (
              <div className="flex items-center space-x-1">
                <button
                  onClick={() => onUpdateAttendance(course.id, -1)}
                  disabled={course.attendedSessions <= 0}
                  className="w-6 h-6 rounded flex items-center justify-center bg-slate-100 hover:bg-slate-200 text-slate-600 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                  title="Giảm 1 buổi"
                >
                  <Minus className="w-3 h-3" />
                </button>
                <button
                  onClick={() => onUpdateAttendance(course.id, 1)}
                  disabled={course.attendedSessions >= course.totalSessions}
                  className="w-6 h-6 rounded flex items-center justify-center bg-amber-500 hover:bg-amber-600 text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors font-bold shadow-xs"
                  title="Điểm danh thêm 1 buổi học"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>

          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                isCompleted ? 'bg-emerald-500' : isInProgress ? 'bg-amber-500' : 'bg-slate-300'
              }`}
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Scores & Outcomes with UFM scale */}
        <div className="mt-3.5 bg-slate-50/80 rounded-lg p-2.5 border border-slate-100">
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <span className="text-[11px] text-slate-400 block">Mục tiêu</span>
              <span className="text-sm font-semibold text-slate-700">
                {course.targetScore !== null ? `${course.targetScore}` : '—'}
              </span>
            </div>
            <div>
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-400 block">Điểm thực tế</span>
                {course.actualScore !== null && (
                  <span className="text-[10px] text-slate-400 font-mono">
                    {scoreToScale4(course.actualScore, gpaStandard)}/4.0
                  </span>
                )}
              </div>
              <div className="flex items-baseline space-x-1.5 mt-0.5">
                <span className="text-base font-extrabold text-slate-900">
                  {course.actualScore !== null ? course.actualScore : '—'}
                </span>
                {course.actualScore !== null && (
                  <span className="text-xs font-bold text-indigo-600">
                    ({scoreToLetter(course.actualScore, gpaStandard)})
                  </span>
                )}
                {diffScore !== null && (
                  <span className={`text-[10px] font-bold ${diffScore >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {diffScore >= 0 ? `+${diffScore}` : diffScore}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Clickable Documents Link & Notes */}
        {(course.documents || course.documentUrl || course.notes) && (
          <div className="mt-3 text-xs space-y-1.5">
            {(course.documents || course.documentUrl) && (
              <div className="flex items-center">
                <DocumentLink
                  documents={course.documents}
                  documentUrl={course.documentUrl}
                  courseName={course.name}
                  onEditLink={() => onEdit(course)}
                />
              </div>
            )}
            {course.notes && (
              <div className="text-slate-500 italic text-[11px] px-1 truncate" title={course.notes}>
                Note: {course.notes}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Card Actions Footer */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
        <button
          onClick={() => onEdit(course)}
          className="text-xs font-medium text-slate-600 hover:text-indigo-600 flex items-center space-x-1 transition-colors"
        >
          <Edit3 className="w-3.5 h-3.5" />
          <span>Sửa</span>
        </button>

        <button
          onClick={() => onDelete(course.id)}
          className="text-xs font-medium text-slate-400 hover:text-rose-600 flex items-center space-x-1 transition-colors"
          title="Xóa môn học này"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
