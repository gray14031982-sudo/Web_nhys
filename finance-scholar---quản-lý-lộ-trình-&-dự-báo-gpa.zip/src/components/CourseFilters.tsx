import React from 'react';
import { Search, Filter, LayoutGrid, Table, X } from 'lucide-react';
import { CourseDifficulty, CourseLanguage, CourseStatus } from '../types/curriculum';

interface CourseFiltersProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  statusFilter: CourseStatus | 'ALL';
  setStatusFilter: (status: CourseStatus | 'ALL') => void;
  difficultyFilter: CourseDifficulty | 'ALL';
  setDifficultyFilter: (diff: CourseDifficulty | 'ALL') => void;
  languageFilter: CourseLanguage | 'ALL';
  setLanguageFilter: (lang: CourseLanguage | 'ALL') => void;
  viewMode: 'cards' | 'table';
  setViewMode: (mode: 'cards' | 'table') => void;
  totalFiltered: number;
}

export const CourseFilters: React.FC<CourseFiltersProps> = ({
  searchQuery,
  setSearchQuery,
  statusFilter,
  setStatusFilter,
  difficultyFilter,
  setDifficultyFilter,
  languageFilter,
  setLanguageFilter,
  viewMode,
  setViewMode,
  totalFiltered,
}) => {
  const hasActiveFilters = 
    searchQuery !== '' || 
    statusFilter !== 'ALL' || 
    difficultyFilter !== 'ALL' || 
    languageFilter !== 'ALL';

  const clearAllFilters = () => {
    setSearchQuery('');
    setStatusFilter('ALL');
    setDifficultyFilter('ALL');
    setLanguageFilter('ALL');
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200/80 p-4 mb-4 shadow-xs">
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        
        {/* Search input */}
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Tìm kiếm môn học, tài liệu, ghi chú, hình thức thi..."
            className="w-full pl-9 pr-9 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Filter controls row */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          
          {/* Status selector */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 cursor-pointer"
          >
            <option value="ALL">Mọi trạng thái</option>
            <option value="Đang học">Đang học (HK 4)</option>
            <option value="Đã học">Đã hoàn thành</option>
            <option value="Chưa học">Chưa học (Sắp tới)</option>
          </select>

          {/* Difficulty selector */}
          <select
            value={difficultyFilter}
            onChange={(e) => setDifficultyFilter(e.target.value as any)}
            className="px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 cursor-pointer"
          >
            <option value="ALL">Mọi mức độ</option>
            <option value="Khó">Mức độ: Khó</option>
            <option value="Trung bình">Mức độ: Trung bình</option>
            <option value="Dễ">Mức độ: Dễ</option>
          </select>

          {/* Language selector */}
          <select
            value={languageFilter}
            onChange={(e) => setLanguageFilter(e.target.value as any)}
            className="px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 cursor-pointer"
          >
            <option value="ALL">Mọi ngôn ngữ</option>
            <option value="Tiếng Anh">Tiếng Anh (TA)</option>
            <option value="Tiếng Việt">Tiếng Việt (TV)</option>
          </select>

          {/* Clear filters button */}
          {hasActiveFilters && (
            <button
              onClick={clearAllFilters}
              className="flex items-center space-x-1 px-2.5 py-2 text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors font-medium"
            >
              <X className="w-3.5 h-3.5" />
              <span>Xóa lọc</span>
            </button>
          )}

          {/* View mode toggle */}
          <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 ml-auto">
            <button
              onClick={() => setViewMode('cards')}
              className={`p-1.5 rounded-md transition-colors ${
                viewMode === 'cards'
                  ? 'bg-white text-indigo-600 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
              title="Xem dạng thẻ học phần"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-md transition-colors ${
                viewMode === 'table'
                  ? 'bg-white text-indigo-600 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
              title="Xem dạng bảng Google Sheet"
            >
              <Table className="w-4 h-4" />
            </button>
          </div>

        </div>

      </div>

      <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
        <span>Hiển thị <strong>{totalFiltered}</strong> học phần phù hợp</span>
        <span>Mẹo: Bạn có thể cập nhật số buổi học bằng nút +/- ngay trên từng môn đang học</span>
      </div>
    </div>
  );
};
