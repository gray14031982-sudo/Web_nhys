import React from 'react';
import { 
  Bell, 
  X, 
  AlertTriangle, 
  Info, 
  CheckCircle2, 
  Clock, 
  GraduationCap,
  ExternalLink
} from 'lucide-react';
import { NotificationItem } from '../types/curriculum';

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
  onMarkAllAsRead: () => void;
  onClearNotifications: () => void;
  onNavigateTab?: (tab: any) => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkAllAsRead,
  onClearNotifications,
  onNavigateTab,
}) => {
  if (!isOpen) return null;

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center sm:justify-end p-4 sm:p-6 bg-slate-900/50 backdrop-blur-xs">
      <div 
        className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-md overflow-hidden max-h-[85vh] flex flex-col sm:mr-4 animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Trung Tâm Thông Báo</h3>
              <p className="text-[11px] text-slate-500">
                {unreadCount > 0 ? `${unreadCount} thông báo mới chưa đọc` : 'Bạn đã đọc tất cả thông báo'}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-1">
            {unreadCount > 0 && (
              <button
                onClick={onMarkAllAsRead}
                className="text-[11px] text-indigo-600 hover:text-indigo-700 font-semibold px-2 py-1 rounded hover:bg-indigo-50 transition-colors"
              >
                Đã đọc hết
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="p-4 overflow-y-auto space-y-3 divide-y divide-slate-100/80 flex-1">
          {notifications.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              Hiện tại không có thông báo nào.
            </div>
          ) : (
            notifications.map((item) => {
              const iconMap = {
                warning: <AlertTriangle className="w-4 h-4 text-amber-500" />,
                info: <Info className="w-4 h-4 text-indigo-500" />,
                success: <CheckCircle2 className="w-4 h-4 text-emerald-500" />,
                deadline: <Clock className="w-4 h-4 text-rose-500" />,
              };

              const bgMap = {
                warning: 'bg-amber-50/50 border-amber-200/60',
                info: 'bg-indigo-50/50 border-indigo-200/60',
                success: 'bg-emerald-50/50 border-emerald-200/60',
                deadline: 'bg-rose-50/50 border-rose-200/60',
              };

              return (
                <div
                  key={item.id}
                  className={`pt-3 first:pt-0 p-3 rounded-xl border transition-all ${
                    bgMap[item.type]
                  } ${!item.read ? 'ring-1 ring-indigo-400/30 font-medium' : 'opacity-90'}`}
                >
                  <div className="flex items-start gap-2.5">
                    <div className="mt-0.5 shrink-0">{iconMap[item.type]}</div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between gap-1">
                        <h4 className="text-xs font-bold text-slate-900 leading-tight">
                          {item.title}
                        </h4>
                        <span className="text-[10px] text-slate-400 whitespace-nowrap">
                          {item.time}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                        {item.message}
                      </p>
                      {item.linkAction && onNavigateTab && (
                        <button
                          onClick={() => {
                            onNavigateTab(item.linkAction);
                            onClose();
                          }}
                          className="mt-2 text-[11px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center space-x-1"
                        >
                          <span>Xem ngay</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-100 bg-slate-50/60 flex items-center justify-between text-xs text-slate-500">
          <span>Quy chế Đại học Tài chính - Marketing (UFM)</span>
          {notifications.length > 0 && (
            <button
              onClick={onClearNotifications}
              className="text-rose-500 hover:text-rose-700 font-medium text-[11px]"
            >
              Xóa tất cả
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
