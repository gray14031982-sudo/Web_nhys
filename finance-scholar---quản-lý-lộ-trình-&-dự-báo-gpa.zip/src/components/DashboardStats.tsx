import React from 'react';
import { 
  Trophy, 
  Award, 
  BookCheck, 
  CalendarClock, 
  TrendingUp, 
  Sparkles,
  School
} from 'lucide-react';
import { Course, GpaStandard, GpaStats } from '../types/curriculum';

interface DashboardStatsProps {
  stats: GpaStats;
  courses: Course[];
  gpaStandard?: GpaStandard;
  onOpenSimulator: () => void;
  onOpenSettings?: () => void;
}

export const DashboardStats: React.FC<DashboardStatsProps> = ({
  stats,
  courses,
  gpaStandard = 'UFM',
  onOpenSimulator,
  onOpenSettings,
}) => {
  // Calculate completed courses stats
  const completedCourses = courses.filter((c) => c.status === 'Đã học' && c.actualScore !== null);
  const targetBeatenCount = completedCourses.filter(
    (c) => c.targetScore !== null && (c.actualScore ?? 0) >= (c.targetScore ?? 0)
  ).length;

  // Current semester courses
  const currentSemesterCourses = courses.filter((c) => c.status === 'Đang học');
  const currentAttendedSessions = currentSemesterCourses.reduce((sum, c) => sum + c.attendedSessions, 0);
  const currentTotalSessions = currentSemesterCourses.reduce((sum, c) => sum + c.totalSessions, 0);
  const currentSessionPercent = currentTotalSessions > 0 
    ? Math.round((currentAttendedSessions / currentTotalSessions) * 100) 
    : 0;

  // Language count
  const englishCourses = courses.filter((c) => c.language === 'Tiếng Anh').length;
  const hardCourses = courses.filter((c) => c.difficulty === 'Khó').length;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      
      {/* Stat Card 1: GPA Thang 10 & Thang 4 UFM */}
      <div className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-xs relative overflow-hidden group hover:border-slate-300 transition-all">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center space-x-1 text-slate-500">
              <span className="text-xs font-semibold uppercase tracking-wider">
                GPA Tích Lũy UFM
              </span>
              <span className="text-[10px] bg-indigo-50 text-indigo-700 px-1 py-0.2 rounded font-bold">
                {gpaStandard}
              </span>
            </div>

            <div className="mt-1 flex items-baseline space-x-2">
              <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
                {stats.gpa10}
              </span>
              <span className="text-sm font-medium text-slate-500">/ 10</span>
              <span className="text-sm font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                {stats.gpa4} / 4.0
              </span>
            </div>
            <div className="mt-2 flex items-center text-xs text-slate-600 font-medium">
              <span>Xếp loại: <strong className="text-emerald-700 font-semibold">{stats.rank}</strong></span>
              <span className="mx-1.5 text-slate-300">·</span>
              <span>Điểm chữ: <strong>{stats.letterGrade}</strong></span>
            </div>
          </div>
          <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
            <Trophy className="w-5 h-5" />
          </div>
        </div>

        <div className="mt-3.5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
          <span className="text-slate-500">Đã tích lũy {stats.coursesCompletedCount} môn</span>
          <button
            onClick={onOpenSimulator}
            className="text-indigo-600 font-semibold hover:text-indigo-700 flex items-center space-x-1"
          >
            <span>Dự báo tốt nghiệp</span>
            <span>&rarr;</span>
          </button>
        </div>
      </div>

      {/* Stat Card 2: Tín Chỉ & Tiến Độ Bằng */}
      <div className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-xs relative overflow-hidden group hover:border-slate-300 transition-all">
        <div className="flex items-start justify-between">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Tín Chỉ Cử Nhân UFM
            </span>
            <div className="mt-1 flex items-baseline space-x-2">
              <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
                {stats.completedCredits}
              </span>
              <span className="text-sm font-medium text-slate-500">/ {stats.totalCredits} TC</span>
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                {Math.round((stats.completedCredits / stats.totalCredits) * 100)}%
              </span>
            </div>
            <div className="mt-2 text-xs text-slate-600">
              <span>Đang học: <strong>{stats.inProgressCredits} TC</strong></span>
              <span className="mx-1.5 text-slate-300">·</span>
              <span>Còn lại: <strong>{stats.remainingCredits} TC</strong></span>
            </div>
          </div>
          <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl">
            <BookCheck className="w-5 h-5" />
          </div>
        </div>

        {/* Mini progress track */}
        <div className="mt-3.5 pt-3 border-t border-slate-100">
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden flex">
            <div
              className="bg-emerald-500 h-full transition-all duration-500"
              style={{ width: `${(stats.completedCredits / stats.totalCredits) * 100}%` }}
              title={`Đã hoàn thành ${stats.completedCredits} TC`}
            />
            <div
              className="bg-amber-400 h-full transition-all duration-500"
              style={{ width: `${(stats.inProgressCredits / stats.totalCredits) * 100}%` }}
              title={`Đang học ${stats.inProgressCredits} TC`}
            />
          </div>
        </div>
      </div>

      {/* Stat Card 3: Tiến Độ Kỳ Hiện Tại (HK 4) */}
      <div className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-xs relative overflow-hidden group hover:border-slate-300 transition-all">
        <div className="flex items-start justify-between">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Học Kỳ 4 (Đang Học)
            </span>
            <div className="mt-1 flex items-baseline space-x-2">
              <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
                {currentAttendedSessions}
              </span>
              <span className="text-sm font-medium text-slate-500">/ {currentTotalSessions} buổi</span>
              <span className="text-xs font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded">
                {currentSessionPercent}%
              </span>
            </div>
            <div className="mt-2 text-xs text-slate-600 flex items-center">
              <span><strong>6 môn học</strong></span>
              <span className="mx-1.5 text-slate-300">·</span>
              <span className="text-amber-600 font-medium">17 tín chỉ kỳ 4</span>
            </div>
          </div>
          <div className="p-2.5 bg-amber-50 text-amber-600 rounded-xl">
            <CalendarClock className="w-5 h-5" />
          </div>
        </div>

        <div className="mt-3.5 pt-3 border-t border-slate-100">
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
            <div
              className="bg-amber-500 h-full transition-all duration-500"
              style={{ width: `${currentSessionPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Stat Card 4: Hiệu Quả Đạt Mục Tiêu & Cơ Cấu */}
      <div className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-xs relative overflow-hidden group hover:border-slate-300 transition-all">
        <div className="flex items-start justify-between">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Chỉ Số Vượt Kỳ Vọng
            </span>
            <div className="mt-1 flex items-baseline space-x-2">
              <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
                {targetBeatenCount}
              </span>
              <span className="text-sm font-medium text-slate-500">/ {completedCourses.length} môn</span>
              <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded">
                {completedCourses.length > 0 ? Math.round((targetBeatenCount / completedCourses.length) * 100) : 0}%
              </span>
            </div>
            <div className="mt-2 text-xs text-slate-600">
              <span>Môn Tiếng Anh: <strong>{englishCourses}</strong></span>
              <span className="mx-1.5 text-slate-300">·</span>
              <span>Môn Khó: <strong>{hardCourses}</strong></span>
            </div>
          </div>
          <div className="p-2.5 bg-purple-50 text-purple-600 rounded-xl">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        <div className="mt-3.5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span className="flex items-center text-emerald-600 font-medium">
            <Sparkles className="w-3.5 h-3.5 mr-1" />
            Phong độ học tập rất cao
          </span>
          {onOpenSettings && (
            <button
              onClick={onOpenSettings}
              className="text-[11px] text-slate-400 hover:text-indigo-600 underline"
            >
              Xem quy chế UFM
            </button>
          )}
        </div>
      </div>

    </div>
  );
};
