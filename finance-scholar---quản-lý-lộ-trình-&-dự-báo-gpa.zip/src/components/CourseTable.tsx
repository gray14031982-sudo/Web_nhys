import React from 'react';
import { Course, GpaStandard } from '../types/curriculum';
import { scoreToLetter, scoreToScale4 } from '../utils/gradeCalculations';
import { Edit3, Trash2, Plus, Minus, CheckCircle2, Clock, CircleDashed } from 'lucide-react';
import { DocumentLink } from './DocumentLink';

interface CourseTableProps {
  courses: Course[];
  gpaStandard?: GpaStandard;
  onEdit: (course: Course) => void;
  onDelete: (courseId: string) => void;
  onUpdateAttendance: (courseId: string, delta: number) => void;
}

export const CourseTable: React.FC<CourseTableProps> = ({
  courses,
  gpaStandard = 'UFM',
  onEdit,
  onDelete,
  onUpdateAttendance,
}) => {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-50/90 border-b border-slate-200 text-slate-600 font-bold tracking-tight">
              <th className="py-3 px-3 min-w-[110px]">Học kỳ</th>
              <th className="py-3 px-3 min-w-[200px]">Tên học phần</th>
              <th className="py-3 px-2 text-center w-12">Số TC</th>
              <th className="py-3 px-2 text-center min-w-[80px]">Ngôn ngữ</th>
              <th className="py-3 px-3 text-center min-w-[130px]">Buổi học / Tiến độ</th>
              <th className="py-3 px-2 text-center w-16">Mục tiêu</th>
              <th className="py-3 px-2 text-center w-24">Điểm thực tế</th>
              <th className="py-3 px-3 text-center min-w-[90px]">Trạng thái</th>
              <th className="py-3 px-3 min-w-[130px]">Hình thức thi</th>
              <th className="py-3 px-2 text-center min-w-[80px]">Độ khó</th>
              <th className="py-3 px-3 min-w-[160px]">Tài liệu & Ghi chú</th>
              <th className="py-3 px-2 text-right w-16">Thao tác</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {courses.length === 0 ? (
              <tr>
                <td colSpan={12} className="py-8 text-center text-slate-400">
                  Không tìm thấy môn học nào khớp với bộ lọc.
                </td>
              </tr>
            ) : (
              courses.map((course) => {
                const progressPercent = course.totalSessions > 0
                  ? Math.min(100, Math.round((course.attendedSessions / course.totalSessions) * 100))
                  : 0;

                const isCurrent = course.status === 'Đang học';
                const isCompleted = course.status === 'Đã học';

                return (
                  <tr
                    key={course.id}
                    className={`hover:bg-slate-50/70 transition-colors ${
                      isCurrent ? 'bg-amber-50/20' : ''
                    }`}
                  >
                    {/* Học kỳ */}
                    <td className="py-2.5 px-3 font-semibold text-slate-600 whitespace-nowrap">
                      {course.semester}
                    </td>

                    {/* Tên học phần */}
                    <td className="py-2.5 px-3 font-bold text-slate-900">
                      <div className="flex items-center space-x-1.5">
                        <span>{course.name}</span>
                        {course.language === 'Tiếng Anh' && (
                          <span className="text-[10px] font-semibold text-indigo-700 bg-indigo-50 px-1 py-0.2 rounded border border-indigo-200">
                            TA
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Số TC */}
                    <td className="py-2.5 px-2 text-center font-bold text-slate-800">
                      {course.credits}
                    </td>

                    {/* Ngôn ngữ */}
                    <td className="py-2.5 px-2 text-center text-slate-600">
                      {course.language}
                    </td>

                    {/* Buổi học & Tiến độ */}
                    <td className="py-2.5 px-3">
                      <div className="flex items-center justify-between gap-1.5">
                        <span className="font-medium text-slate-700 whitespace-nowrap">
                          {course.attendedSessions}/{course.totalSessions} ({progressPercent}%)
                        </span>

                        {isCurrent && (
                          <div className="flex items-center space-x-0.5">
                            <button
                              onClick={() => onUpdateAttendance(course.id, -1)}
                              disabled={course.attendedSessions <= 0}
                              className="w-5 h-5 rounded flex items-center justify-center bg-slate-200 hover:bg-slate-300 text-slate-700 disabled:opacity-30 disabled:cursor-not-allowed"
                              title="Giảm 1 buổi"
                            >
                              <Minus className="w-2.5 h-2.5" />
                            </button>
                            <button
                              onClick={() => onUpdateAttendance(course.id, 1)}
                              disabled={course.attendedSessions >= course.totalSessions}
                              className="w-5 h-5 rounded flex items-center justify-center bg-amber-500 hover:bg-amber-600 text-white disabled:opacity-30 disabled:cursor-not-allowed font-bold"
                              title="Điểm danh +1 buổi"
                            >
                              <Plus className="w-2.5 h-2.5" />
                            </button>
                          </div>
                        )}
                      </div>

                      {/* Mini bar */}
                      <div className="w-full bg-slate-100 h-1 rounded-full mt-1 overflow-hidden">
                        <div
                          className={`h-full ${
                            isCompleted ? 'bg-emerald-500' : isCurrent ? 'bg-amber-500' : 'bg-slate-300'
                          }`}
                          style={{ width: `${progressPercent}%` }}
                        />
                      </div>
                    </td>

                    {/* Mục tiêu */}
                    <td className="py-2.5 px-2 text-center text-slate-500 font-medium">
                      {course.targetScore !== null ? course.targetScore : '—'}
                    </td>

                    {/* Điểm thực tế (Thang 10 & Thang 4 UFM) */}
                    <td className="py-2.5 px-2 text-center">
                      {course.actualScore !== null ? (
                        <div className="inline-flex flex-col items-center">
                          <div className="flex items-baseline space-x-1">
                            <span className="font-extrabold text-slate-900 text-sm">
                              {course.actualScore}
                            </span>
                            <span className="text-[10px] font-bold text-indigo-600">
                              ({scoreToLetter(course.actualScore, gpaStandard)})
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {scoreToScale4(course.actualScore, gpaStandard)}/4.0
                          </span>
                        </div>
                      ) : (
                        <span className="text-slate-400">—</span>
                      )}
                    </td>

                    {/* Trạng thái */}
                    <td className="py-2.5 px-3 text-center whitespace-nowrap">
                      {isCompleted && (
                        <span className="inline-flex items-center text-emerald-700 font-semibold text-[11px]">
                          <CheckCircle2 className="w-3 h-3 mr-1" />
                          Đã học
                        </span>
                      )}
                      {isCurrent && (
                        <span className="inline-flex items-center text-amber-700 font-bold text-[11px]">
                          <Clock className="w-3 h-3 mr-1" />
                          Đang học
                        </span>
                      )}
                      {!isCompleted && !isCurrent && (
                        <span className="inline-flex items-center text-slate-400 text-[11px]">
                          <CircleDashed className="w-3 h-3 mr-1" />
                          Chưa học
                        </span>
                      )}
                    </td>

                    {/* Hình thức thi */}
                    <td className="py-2.5 px-3 text-slate-700 font-medium truncate max-w-[140px]" title={course.examFormat}>
                      {course.examFormat || '—'}
                    </td>

                    {/* Độ khó */}
                    <td className="py-2.5 px-2 text-center font-semibold">
                      <span className={
                        course.difficulty === 'Khó' ? 'text-rose-600' :
                        course.difficulty === 'Trung bình' ? 'text-amber-600' : 'text-emerald-600'
                      }>
                        {course.difficulty}
                      </span>
                    </td>

                    {/* Tài liệu & Ghi chú (Clickable) */}
                    <td className="py-2.5 px-3">
                      <div className="space-y-1 max-w-[200px]">
                        {(course.documents || course.documentUrl) && (
                          <div>
                            <DocumentLink
                              documents={course.documents}
                              documentUrl={course.documentUrl}
                              courseName={course.name}
                            />
                          </div>
                        )}
                        {course.notes && (
                          <div className="text-slate-500 italic truncate text-[11px]" title={course.notes}>
                            Note: {course.notes}
                          </div>
                        )}
                        {!course.documents && !course.documentUrl && !course.notes && (
                          <span className="text-slate-300">—</span>
                        )}
                      </div>
                    </td>

                    {/* Thao tác */}
                    <td className="py-2.5 px-2 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end space-x-1">
                        <button
                          onClick={() => onEdit(course)}
                          className="p-1 text-slate-400 hover:text-indigo-600 rounded transition-colors"
                          title="Chỉnh sửa"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onDelete(course.id)}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                          title="Xóa môn"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
