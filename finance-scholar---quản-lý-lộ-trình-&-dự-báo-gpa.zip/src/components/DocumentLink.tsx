import React from 'react';
import { ExternalLink, FileText, Link as LinkIcon } from 'lucide-react';

interface DocumentLinkProps {
  documents: string;
  documentUrl?: string;
  courseName?: string;
  onEditLink?: () => void;
  className?: string;
}

export const DocumentLink: React.FC<DocumentLinkProps> = ({
  documents,
  documentUrl,
  courseName,
  onEditLink,
  className = '',
}) => {
  if (!documents && !documentUrl) return null;

  // Determine target URL
  let targetUrl = documentUrl?.trim() || '';

  if (!targetUrl && documents) {
    if (documents.startsWith('http://') || documents.startsWith('https://')) {
      targetUrl = documents;
    } else {
      // Default to Google Drive search for this document/course
      targetUrl = `https://drive.google.com/drive/search?q=${encodeURIComponent(documents)}`;
    }
  }

  const displayText = documents || 'Xem tài liệu học tập';

  return (
    <a
      href={targetUrl}
      target="_blank"
      rel="noopener noreferrer"
      title={`Mở tài liệu: ${displayText} (Nhấn để mở liên kết)`}
      onClick={(e) => {
        e.stopPropagation();
      }}
      className={`inline-flex items-center space-x-1.5 text-indigo-700 bg-indigo-50/80 hover:bg-indigo-100 hover:text-indigo-900 border border-indigo-200/80 px-2.5 py-1 rounded-md text-xs font-semibold transition-all group shadow-2xs ${className}`}
    >
      <FileText className="w-3.5 h-3.5 text-indigo-600 shrink-0 group-hover:scale-110 transition-transform" />
      <span className="truncate max-w-[200px]">{displayText}</span>
      <ExternalLink className="w-3 h-3 text-indigo-400 group-hover:text-indigo-700 shrink-0 ml-0.5" />
    </a>
  );
};
