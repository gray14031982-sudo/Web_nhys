import React from 'react';
import { CheckCircle2, Clock, Calendar } from 'lucide-react';
import { Course, GpaStandard, SemesterId, SemesterInfo } from '../types/curriculum';
import { SEMESTER_LIST } from '../data/initialCourses';
import { calculateSemesterSummary } from '../utils/gradeCalculations';

interface SemesterTimelineProps {
  courses: Course[];
  semesters?: SemesterInfo[];
  selectedSemester: SemesterId | 'ALL';
  gpaStandard?: GpaStandard;
  onSelectSemester: (semesterId: SemesterId | 'ALL') => void;
}

export const SemesterTimeline: React.FC<SemesterTimelineProps> = ({
  courses,
  semesters = SEMESTER_LIST,
  selectedSemester,
  gpaStandard = 'UFM',
  onSelectSemester,
}) => {
  return (
    <div className="bg-white rounded-xl border border-slate-200/80 p-4 mb-6 shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-3 mb-3 border-b border-slate-100 gap-2">
        <div className="flex items-center space-x-2">
          <Calendar className="w-4 h-4 text-indigo-600" />
          <h2 className="text-sm font-bold text-slate-800 tracking-tight">
            Lộ Trình Cử Nhân UFM ({semesters.length} Học Kỳ)
          </h2>
          <span className="text-xs text-slate-400">· Nhấn vào học kỳ để xem chi tiết</span>
        </div>

        <button
          onClick={() => onSelectSemester('ALL')}
          className={`text-xs px-3 py-1 rounded-md font-medium transition-colors ${
            selectedSemester === 'ALL'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 bg-slate-100'
          }`}
        >
          Xem tất cả học kỳ
        </button>
      </div>

      {/* Horizontal timeline cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
        {semesters.map((sem) => {
          const summary = calculateSemesterSummary(courses, sem.id, gpaStandard);
          const isSelected = selectedSemester === sem.id;
          const isCurrent = sem.isCurrent;
          const isCompleted = summary.gpa10 !== null;

          return (
            <button
              key={sem.id}
              onClick={() => onSelectSemester(sem.id)}
              className={`p-3 rounded-xl text-left border transition-all relative flex flex-col justify-between ${
                isSelected
                  ? 'border-indigo-600 ring-2 ring-indigo-500/20 bg-indigo-50/40 shadow-xs'
                  : isCurrent
                  ? 'border-amber-400/80 bg-amber-50/30 hover:border-amber-500'
                  : 'border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50/60'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                    {sem.id.split(' - ')[0] || sem.id}
                  </span>
                  {isCompleted ? (
                    <span className="flex items-center text-[11px] font-semibold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                      <CheckCircle2 className="w-3 h-3 mr-0.5" />
                      Xong
                    </span>
                  ) : isCurrent ? (
                    <span className="flex items-center text-[11px] font-bold text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded animate-pulse">
                      <Clock className="w-3 h-3 mr-0.5" />
                      Đang học
                    </span>
                  ) : (
                    <span className="text-[10px] text-slate-400 font-medium">Dự kiến</span>
                  )}
                </div>

                <div className="font-bold text-slate-900 text-sm tracking-tight truncate">
                  {sem.id.includes(' - ') ? sem.id.split(' - ')[1] : sem.id}
                </div>

                <div className="text-[11px] text-slate-500 mt-1">
                  <span>{summary.courseCount} môn</span>
                  <span className="mx-1 text-slate-300">·</span>
                  <span>{summary.totalCredits} TC</span>
                </div>
              </div>

              {/* Bottom detail: GPA or progress */}
              <div className="mt-2.5 pt-2 border-t border-slate-100/80 flex items-center justify-between text-xs">
                {isCompleted ? (
                  <div className="flex items-baseline space-x-1">
                    <span className="text-slate-400 text-[10px]">GPA:</span>
                    <span className="font-bold text-indigo-700">{summary.gpa10}</span>
                    <span className="text-slate-400 text-[10px]">({summary.gpa4}/4 UFM)</span>
                  </div>
                ) : isCurrent ? (
                  <div className="w-full">
                    <div className="flex items-center justify-between text-[10px] text-amber-800 font-semibold mb-1">
                      <span>Buổi học</span>
                      <span>{summary.sessionProgress}%</span>
                    </div>
                    <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-amber-500 h-full rounded-full"
                        style={{ width: `${summary.sessionProgress}%` }}
                      />
                    </div>
                  </div>
                ) : (
                  <span className="text-[10px] text-slate-400 italic">Chưa mở lớp</span>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
