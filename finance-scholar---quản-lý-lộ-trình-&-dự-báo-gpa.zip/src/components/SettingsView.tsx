import React, { useState, useEffect } from 'react';
import { 
  Settings as SettingsIcon, 
  Database, 
  GraduationCap, 
  Download, 
  Upload, 
  RotateCcw, 
  Plus, 
  Trash2, 
  Check, 
  AlertCircle,
  HelpCircle,
  School,
  FileJson,
  Save,
  Clock,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';
import { Course, GpaStandard, NotificationItem, SemesterId, SemesterInfo } from '../types/curriculum';

interface SettingsViewProps {
  gpaStandard: GpaStandard;
  onSetGpaStandard: (std: GpaStandard) => void;
  semesters: SemesterInfo[];
  onAddSemester: (newSem: SemesterInfo) => void;
  onSetCurrentSemester: (semId: SemesterId) => void;
  courses: Course[];
  notifications: NotificationItem[];
  onImportFullBackup: (backup: {
    courses: Course[];
    semesters?: SemesterInfo[];
    notifications?: NotificationItem[];
    gpaStandard?: GpaStandard;
  }) => void;
  onResetOriginalData: () => void;
  onShowToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  gpaStandard,
  onSetGpaStandard,
  semesters,
  onAddSemester,
  onSetCurrentSemester,
  courses,
  notifications,
  onImportFullBackup,
  onResetOriginalData,
  onShowToast,
}) => {
  // New semester form state
  const [newSemYear, setNewSemYear] = useState<number>(4);
  const [newSemNum, setNewSemNum] = useState<number>(7);
  const [newSemTitle, setNewSemTitle] = useState<string>('Học kỳ hè');

  // JSON input state for manual editor
  const [jsonInput, setJsonInput] = useState<string>('');
  const [showJsonBox, setShowJsonBox] = useState<boolean>(false);

  // Auto-save settings state
  const [autoSaveEnabled, setAutoSaveEnabled] = useState<boolean>(() => {
    return localStorage.getItem('ufm_auto_save_enabled') === 'true';
  });
  const [lastBackupTime, setLastBackupTime] = useState<string>(() => {
    return localStorage.getItem('ufm_last_backup_time') || 'Chưa thực hiện';
  });

  // Student profile state
  const [studentName, setStudentName] = useState(() => localStorage.getItem('ufm_student_name') || 'Sinh viên UFM');
  const [studentId, setStudentId] = useState(() => localStorage.getItem('ufm_student_id') || '22DTC...');
  const [major, setMajor] = useState(() => localStorage.getItem('ufm_student_major') || 'Tài chính - Ngân hàng');

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('ufm_student_name', studentName);
    localStorage.setItem('ufm_student_id', studentId);
    localStorage.setItem('ufm_student_major', major);
    onShowToast('Đã lưu thông tin sinh viên thành công!', 'success');
  };

  const handleAddSemesterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const semId = `Năm ${newSemYear} - HK ${newSemNum} (${newSemTitle})`;
    const exists = semesters.some((s) => s.id === semId);
    if (exists) {
      onShowToast('Học kỳ này đã tồn tại trong danh sách!', 'error');
      return;
    }

    const newSem: SemesterInfo = {
      id: semId,
      year: newSemYear,
      semesterNum: newSemNum,
      title: `${newSemTitle} (Năm ${newSemYear})`,
    };

    onAddSemester(newSem);
    onShowToast(`Đã thêm học kỳ "${semId}" vào lộ trình!`, 'success');
  };

  // Comprehensive Auto-save / Download Full Backup JSON
  const handleDownloadFullBackupJson = () => {
    const now = new Date();
    const timestampStr = now.toLocaleString('vi-VN');
    const isoDate = now.toISOString().slice(0, 10);

    const fullAppState = {
      app: 'Finance Scholar UFM - Quản Lý Lộ Trình & Dự Báo GPA',
      version: '2.0.0',
      university: 'Trường Đại học Tài chính - Marketing (UFM)',
      backupTimestamp: now.toISOString(),
      backupTimeHuman: timestampStr,
      gpaStandard,
      studentProfile: {
        name: studentName,
        studentId,
        major,
      },
      statsSummary: {
        totalCourses: courses.length,
        totalSemesters: semesters.length,
        totalNotifications: notifications.length,
      },
      semesters,
      courses,
      notifications,
    };

    const dataStr = JSON.stringify(fullAppState, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `UFM_FullAppState_${isoDate}_${now.getHours()}h${now.getMinutes()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    // Update last backup time
    setLastBackupTime(timestampStr);
    localStorage.setItem('ufm_last_backup_time', timestampStr);

    onShowToast('Đã xuất và tải xuống toàn bộ trạng thái ứng dụng thành công!', 'success');
  };

  const handleToggleAutoSave = (checked: boolean) => {
    setAutoSaveEnabled(checked);
    localStorage.setItem('ufm_auto_save_enabled', checked ? 'true' : 'false');
    if (checked) {
      onShowToast('Đã bật tính năng tự động ghi nhớ và lưu sao lưu JSON!', 'success');
    } else {
      onShowToast('Đã tắt tự động sao lưu.', 'info');
    }
  };

  const handleImportJsonFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        
        // Handle full backup or simple courses array
        const importedCourses = Array.isArray(parsed) ? parsed : parsed.courses;
        const importedSemesters = parsed.semesters;
        const importedNotifs = parsed.notifications;
        const importedStd = parsed.gpaStandard;

        if (Array.isArray(importedCourses) && importedCourses.length > 0) {
          onImportFullBackup({
            courses: importedCourses,
            semesters: Array.isArray(importedSemesters) ? importedSemesters : undefined,
            notifications: Array.isArray(importedNotifs) ? importedNotifs : undefined,
            gpaStandard: importedStd === 'MOET' ? 'MOET' : 'UFM',
          });

          if (parsed.studentProfile) {
            if (parsed.studentProfile.name) {
              setStudentName(parsed.studentProfile.name);
              localStorage.setItem('ufm_student_name', parsed.studentProfile.name);
            }
            if (parsed.studentProfile.studentId) {
              setStudentId(parsed.studentProfile.studentId);
              localStorage.setItem('ufm_student_id', parsed.studentProfile.studentId);
            }
            if (parsed.studentProfile.major) {
              setMajor(parsed.studentProfile.major);
              localStorage.setItem('ufm_student_major', parsed.studentProfile.major);
            }
          }

          onShowToast(`Đã khôi phục thành công toàn bộ ${importedCourses.length} môn học và trạng thái từ file JSON!`, 'success');
        } else {
          onShowToast('File JSON không chứa danh sách môn học hợp lệ.', 'error');
        }
      } catch (err) {
        onShowToast('Lỗi khi đọc file JSON. Vui lòng kiểm tra định dạng file.', 'error');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleManualJsonImport = () => {
    try {
      const parsed = JSON.parse(jsonInput);
      const importedCourses = Array.isArray(parsed) ? parsed : parsed.courses;
      if (Array.isArray(importedCourses) && importedCourses.length > 0) {
        onImportFullBackup({
          courses: importedCourses,
          semesters: parsed.semesters,
          notifications: parsed.notifications,
          gpaStandard: parsed.gpaStandard,
        });
        setShowJsonBox(false);
        setJsonInput('');
        onShowToast(`Đã nhập thành công ${importedCourses.length} môn học từ mã JSON!`, 'success');
      } else {
        onShowToast('Dữ liệu JSON không hợp lệ.', 'error');
      }
    } catch (e) {
      onShowToast('Mã JSON không đúng cú pháp.', 'error');
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Settings Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <SettingsIcon className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              Cài Đặt Hệ Thống & Quản Lý Dữ Liệu
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Cấu hình chuẩn quy chế Trường Đại học Tài chính - Marketing (UFM), tính năng Auto-save to JSON và quản lý học kỳ.
            </p>
          </div>
        </div>
      </div>

      {/* FEATURE: Auto-Save to JSON Card (Prominent Hero) */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-6 sm:p-7 shadow-md border border-indigo-900/80">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center space-x-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4" />
              <span>Tính Năng An Toàn Dữ Liệu Học Vụ</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              Auto-Save to JSON (Sao Lưu Toàn Bộ Trạng Thái)
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Tải xuống bản snapshot hoàn chỉnh chứa toàn bộ dữ liệu <strong>môn học ({courses.length})</strong>, <strong>học kỳ ({semesters.length})</strong>, <strong>thông báo ({notifications.length})</strong>, chuẩn GPA UFM và thông tin hồ sơ của bạn dưới dạng file <code className="bg-slate-800 text-emerald-300 px-1.5 py-0.5 rounded font-mono text-xs">.json</code>.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-1 text-xs text-slate-400">
              <div className="flex items-center space-x-1.5">
                <Clock className="w-3.5 h-3.5 text-indigo-400" />
                <span>Sao lưu gần nhất: <strong className="text-white">{lastBackupTime}</strong></span>
              </div>
              <span className="text-slate-600">·</span>
              <div className="flex items-center space-x-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Định dạng chuẩn JSON UTF-8</span>
              </div>
            </div>
          </div>

          {/* Action Button & Toggle */}
          <div className="flex flex-col sm:flex-row lg:flex-col gap-3 shrink-0">
            <button
              onClick={handleDownloadFullBackupJson}
              className="px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs sm:text-sm transition-all shadow-md flex items-center justify-center space-x-2 group hover:scale-[1.02]"
            >
              <Download className="w-4 h-4 group-hover:-translate-y-0.5 transition-transform" />
              <span>Tải Xuống Bản Sao Lưu .JSON</span>
            </button>

            <label className="flex items-center justify-center space-x-2 px-3.5 py-2 rounded-lg bg-slate-800/80 border border-slate-700 cursor-pointer hover:bg-slate-800 transition-colors">
              <input
                type="checkbox"
                checked={autoSaveEnabled}
                onChange={(e) => handleToggleAutoSave(e.target.checked)}
                className="rounded accent-indigo-500 w-4 h-4 cursor-pointer"
              />
              <span className="text-xs text-slate-300 font-medium">
                Tự động nhắc tải file sau mỗi kỳ cập nhật
              </span>
            </label>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Section 1: UFM Grading Regulations */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center space-x-2">
                <School className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-slate-900 text-sm">
                  Chuẩn Thang Điểm & Công Thức GPA UFM
                </h3>
              </div>
              <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                QĐ 3279 & QĐ 1086/QĐ-ĐHTCM
              </span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed mb-4">
              Tại Trường Đại học Tài chính - Marketing (UFM), thang điểm 4 có đặc thù quy đổi chính xác theo quyết định của Hiệu trưởng:
              Mức <strong>8.5 – 8.9 quy đổi thành điểm A (3.8)</strong>, và chỉ mức <strong>9.0 – 10.0 mới đạt A+ (4.0)</strong>.
            </p>

            {/* Standard Selector */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2 mb-4">
              <label className="text-xs font-bold text-slate-800 block">
                Lựa chọn chuẩn tính toán GPA:
              </label>

              <div className="flex flex-col sm:flex-row gap-2">
                <label className={`flex-1 flex items-start p-2.5 rounded-lg border cursor-pointer transition-all ${
                  gpaStandard === 'UFM' 
                    ? 'border-indigo-600 bg-indigo-50/50 text-indigo-950 font-bold' 
                    : 'border-slate-200 bg-white text-slate-700'
                }`}>
                  <input
                    type="radio"
                    name="standard"
                    checked={gpaStandard === 'UFM'}
                    onChange={() => {
                      onSetGpaStandard('UFM');
                      onShowToast('Đã áp dụng chuẩn GPA chính thức của Đại học UFM!', 'success');
                    }}
                    className="mt-0.5 mr-2 accent-indigo-600"
                  />
                  <div>
                    <span className="text-xs block">Chuẩn UFM (Khuyên dùng)</span>
                    <span className="text-[10px] text-slate-500 font-normal">
                      A+ (4.0) | A (3.8) | B+ (3.5) | B (3.0) | C+ (2.5)
                    </span>
                  </div>
                </label>

                <label className={`flex-1 flex items-start p-2.5 rounded-lg border cursor-pointer transition-all ${
                  gpaStandard === 'MOET' 
                    ? 'border-indigo-600 bg-indigo-50/50 text-indigo-950 font-bold' 
                    : 'border-slate-200 bg-white text-slate-700'
                }`}>
                  <input
                    type="radio"
                    name="standard"
                    checked={gpaStandard === 'MOET'}
                    onChange={() => {
                      onSetGpaStandard('MOET');
                      onShowToast('Đã chuyển sang chuẩn Bộ GD&ĐT chung', 'info');
                    }}
                    className="mt-0.5 mr-2 accent-indigo-600"
                  />
                  <div>
                    <span className="text-xs block">Chuẩn Chung Bộ GD&ĐT</span>
                    <span className="text-[10px] text-slate-500 font-normal">
                      A (4.0 từ 8.5) | B+ (3.5) | B (3.0)
                    </span>
                  </div>
                </label>
              </div>
            </div>

            {/* UFM Official Scale Table */}
            <div className="overflow-x-auto rounded-lg border border-slate-200">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-bold">
                    <th className="py-2 px-2.5">Thang 10</th>
                    <th className="py-2 px-2.5">Thang 4 UFM</th>
                    <th className="py-2 px-2.5">Điểm chữ</th>
                    <th className="py-2 px-2.5">Xếp loại</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  <tr className="hover:bg-slate-50">
                    <td className="py-1.5 px-2.5">9.0 – 10.0</td>
                    <td className="py-1.5 px-2.5 font-bold text-indigo-600">4.0</td>
                    <td className="py-1.5 px-2.5 font-bold text-emerald-600">A+</td>
                    <td className="py-1.5 px-2.5 text-slate-700">Xuất sắc</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-1.5 px-2.5">8.5 – 8.9</td>
                    <td className="py-1.5 px-2.5 font-bold text-indigo-600">3.8</td>
                    <td className="py-1.5 px-2.5 font-bold text-emerald-600">A</td>
                    <td className="py-1.5 px-2.5 text-slate-700">Giỏi</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-1.5 px-2.5">8.0 – 8.4</td>
                    <td className="py-1.5 px-2.5 font-bold text-indigo-600">3.5</td>
                    <td className="py-1.5 px-2.5 font-bold text-indigo-600">B+</td>
                    <td className="py-1.5 px-2.5 text-slate-700">Khá</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-1.5 px-2.5">7.0 – 7.9</td>
                    <td className="py-1.5 px-2.5 font-bold text-indigo-600">3.0</td>
                    <td className="py-1.5 px-2.5 font-bold text-indigo-600">B</td>
                    <td className="py-1.5 px-2.5 text-slate-700">Khá</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-1.5 px-2.5">6.0 – 6.9</td>
                    <td className="py-1.5 px-2.5 font-bold text-slate-700">2.5</td>
                    <td className="py-1.5 px-2.5 font-bold text-amber-600">C+</td>
                    <td className="py-1.5 px-2.5 text-slate-700">Trung bình</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-1.5 px-2.5">5.5 – 5.9</td>
                    <td className="py-1.5 px-2.5 font-bold text-slate-700">2.0</td>
                    <td className="py-1.5 px-2.5 font-bold text-amber-600">C</td>
                    <td className="py-1.5 px-2.5 text-slate-700">Trung bình</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-1.5 px-2.5">5.0 – 5.4</td>
                    <td className="py-1.5 px-2.5 font-bold text-slate-500">1.5</td>
                    <td className="py-1.5 px-2.5 font-bold text-slate-600">D+</td>
                    <td className="py-1.5 px-2.5 text-slate-700">Yếu</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-1.5 px-2.5">4.0 – 4.9</td>
                    <td className="py-1.5 px-2.5 font-bold text-slate-500">1.0</td>
                    <td className="py-1.5 px-2.5 font-bold text-slate-600">D</td>
                    <td className="py-1.5 px-2.5 text-slate-700">Yếu</td>
                  </tr>
                  <tr className="hover:bg-slate-50 bg-rose-50/30">
                    <td className="py-1.5 px-2.5 text-rose-700">Dưới 4.0</td>
                    <td className="py-1.5 px-2.5 font-bold text-rose-600">0.0</td>
                    <td className="py-1.5 px-2.5 font-bold text-rose-600">F</td>
                    <td className="py-1.5 px-2.5 text-rose-600">Kém (Học lại)</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-500">
            * Điểm qua môn tại UFM: Điểm tổng kết ĐTK $\ge$ 4.0, Điểm thi cuối kỳ $\ge$ 3.0 và Giữa kỳ &gt; 0.
          </div>
        </div>

        {/* Section 2: Student Profile & Semesters Management */}
        <div className="space-y-6">
          
          {/* Profile Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
            <h3 className="font-bold text-slate-900 text-sm mb-3 flex items-center space-x-2">
              <GraduationCap className="w-4 h-4 text-indigo-600" />
              <span>Hồ Sơ Sinh Viên UFM</span>
            </h3>

            <form onSubmit={handleSaveProfile} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Họ và tên</label>
                  <input
                    type="text"
                    value={studentName}
                    onChange={(e) => setStudentName(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Mã số sinh viên (MSSV)</label>
                  <input
                    type="text"
                    value={studentId}
                    onChange={(e) => setStudentId(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Chuyên ngành đào tạo</label>
                <input
                  type="text"
                  value={major}
                  onChange={(e) => setMajor(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-semibold transition-colors shadow-xs"
                >
                  Lưu Thông Tin
                </button>
              </div>
            </form>
          </div>

          {/* Add Custom Semester */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
            <h3 className="font-bold text-slate-900 text-sm mb-3 flex items-center space-x-2">
              <Plus className="w-4 h-4 text-emerald-600" />
              <span>Thêm Học Kỳ Mới Vào Lộ Trình</span>
            </h3>

            <form onSubmit={handleAddSemesterSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Năm thứ</label>
                  <input
                    type="number"
                    min="1"
                    max="6"
                    value={newSemYear}
                    onChange={(e) => setNewSemYear(parseInt(e.target.value) || 1)}
                    className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-medium"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Số HK</label>
                  <input
                    type="number"
                    min="1"
                    max="15"
                    value={newSemNum}
                    onChange={(e) => setNewSemNum(parseInt(e.target.value) || 1)}
                    className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-medium"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Ghi chú / Tên HK</label>
                  <input
                    type="text"
                    value={newSemTitle}
                    onChange={(e) => setNewSemTitle(e.target.value)}
                    placeholder="VD: HK hè, HK 11..."
                    className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-medium"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold transition-colors flex items-center space-x-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Thêm Kỳ Học</span>
                </button>
              </div>
            </form>
          </div>

        </div>

      </div>

      {/* Section 3: Data Backup, Import & Reset */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
        <div className="flex items-center space-x-2 pb-3 border-b border-slate-100 mb-4">
          <Database className="w-5 h-5 text-indigo-600" />
          <h3 className="font-bold text-slate-900 text-sm">
            Sao Lưu Toàn Bộ & Phục Hồi Dữ Liệu (Backup & Restore)
          </h3>
        </div>

        <p className="text-xs text-slate-600 mb-5 leading-relaxed">
          Bạn có thể tải file <strong className="text-indigo-600 font-mono">.json</strong> để lưu trữ offline hoặc nhập lại khi cần chuyển máy.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          
          {/* Button 1: Download Full Backup JSON */}
          <button
            onClick={handleDownloadFullBackupJson}
            className="p-4 rounded-xl border border-indigo-200 bg-indigo-50/40 hover:bg-indigo-50 hover:border-indigo-300 text-indigo-900 text-left transition-all group flex flex-col justify-between"
          >
            <div>
              <FileJson className="w-5 h-5 text-indigo-600 mb-2" />
              <div className="font-bold text-xs">Tải Toàn Bộ Backup (.JSON)</div>
              <p className="text-[11px] text-slate-500 mt-1">Lưu trữ đầy đủ môn, kỳ, thông báo</p>
            </div>
            <div className="mt-3 text-[11px] font-bold text-indigo-600 flex items-center space-x-1">
              <span>Tải file JSON ngay</span>
              <Download className="w-3 h-3 ml-1" />
            </div>
          </button>

          {/* Button 2: Import JSON File */}
          <label className="p-4 rounded-xl border border-slate-200 bg-slate-50/40 hover:bg-slate-50 hover:border-slate-300 text-slate-900 text-left transition-all cursor-pointer flex flex-col justify-between">
            <input
              type="file"
              accept=".json"
              onChange={handleImportJsonFile}
              className="hidden"
            />
            <div>
              <Upload className="w-5 h-5 text-slate-700 mb-2" />
              <div className="font-bold text-xs">Phục Hồi File JSON</div>
              <p className="text-[11px] text-slate-500 mt-1">Khôi phục từ bản sao lưu trước đó</p>
            </div>
            <div className="mt-3 text-[11px] font-bold text-slate-700 flex items-center space-x-1">
              <span>Chọn file từ máy</span>
              <Upload className="w-3 h-3 ml-1" />
            </div>
          </label>

          {/* Button 3: Manual JSON Editor */}
          <button
            onClick={() => setShowJsonBox(!showJsonBox)}
            className="p-4 rounded-xl border border-slate-200 bg-slate-50/40 hover:bg-slate-50 hover:border-slate-300 text-slate-900 text-left transition-all flex flex-col justify-between"
          >
            <div>
              <Database className="w-5 h-5 text-slate-700 mb-2" />
              <div className="font-bold text-xs">Dán Mã JSON Trực Tiếp</div>
              <p className="text-[11px] text-slate-500 mt-1">Chỉnh sửa nhanh qua text editor</p>
            </div>
            <div className="mt-3 text-[11px] font-bold text-slate-700">
              {showJsonBox ? 'Đóng hộp nhập' : 'Mở hộp nhập'}
            </div>
          </button>

          {/* Button 4: Reset original sheet data */}
          <button
            onClick={() => {
              if (window.confirm('Bạn có chắc chắn muốn khôi phục về dữ liệu sheet UFM gốc ban đầu? Mọi tùy chỉnh hiện tại sẽ được thay thế.')) {
                onResetOriginalData();
                onShowToast('Đã khôi phục về dữ liệu sheet gốc UFM!', 'info');
              }
            }}
            className="p-4 rounded-xl border border-rose-200 bg-rose-50/30 hover:bg-rose-50 text-rose-900 text-left transition-all flex flex-col justify-between"
          >
            <div>
              <RotateCcw className="w-5 h-5 text-rose-600 mb-2" />
              <div className="font-bold text-xs">Khôi Phục Dữ Liệu Gốc</div>
              <p className="text-[11px] text-rose-600/80 mt-1">Nạp lại 47 môn theo sheet mẫu UFM</p>
            </div>
            <div className="mt-3 text-[11px] font-bold text-rose-700">
              Thiết lập lại
            </div>
          </button>

        </div>

        {/* Manual JSON textarea modal */}
        {showJsonBox && (
          <div className="mt-5 p-4 rounded-xl border border-slate-300 bg-slate-900 text-white space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-mono text-indigo-400">Dán dữ liệu JSON của ứng dụng hoặc danh sách môn học:</span>
              <button
                onClick={() => setShowJsonBox(false)}
                className="text-slate-400 hover:text-white"
              >
                Đóng
              </button>
            </div>
            <textarea
              rows={6}
              value={jsonInput}
              onChange={(e) => setJsonInput(e.target.value)}
              placeholder='{ "courses": [ ... ], "semesters": [ ... ], "gpaStandard": "UFM" }'
              className="w-full p-2.5 text-xs bg-slate-950 font-mono text-emerald-400 border border-slate-700 rounded-lg focus:outline-none"
            />
            <div className="flex justify-end space-x-2">
              <button
                onClick={handleManualJsonImport}
                className="px-4 py-1.5 text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors"
              >
                Áp Dụng Dữ Liệu
              </button>
            </div>
          </div>
        )}

      </div>

    </div>
  );
};
