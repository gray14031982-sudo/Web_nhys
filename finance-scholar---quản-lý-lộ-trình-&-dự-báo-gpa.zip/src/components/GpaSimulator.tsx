import React, { useState, useMemo } from 'react';
import { 
  Calculator, 
  Sparkles, 
  Trophy, 
  RotateCcw, 
  CheckCircle2, 
  AlertCircle, 
  School,
  TrendingUp,
  LineChart as LineChartIcon,
  Layers
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ReferenceLine 
} from 'recharts';
import { Course, GpaStandard, GpaStats, SemesterInfo } from '../types/curriculum';
import { SEMESTER_LIST } from '../data/initialCourses';
import { calculateGpaStats, calculateRequiredAverage, getRankFromGpa4, scoreToLetter, scoreToScale4 } from '../utils/gradeCalculations';

interface GpaSimulatorProps {
  courses: Course[];
  currentStats: GpaStats;
  gpaStandard?: GpaStandard;
  onUpdateCourseSimulatedScore: (courseId: string, score: number | null) => void;
  onBatchSimulateScores: (scores: Record<string, number | null>) => void;
  onResetSimulation: () => void;
}

export const GpaSimulator: React.FC<GpaSimulatorProps> = ({
  courses,
  currentStats,
  gpaStandard = 'UFM',
  onUpdateCourseSimulatedScore,
  onBatchSimulateScores,
  onResetSimulation,
}) => {
  const [targetDegree, setTargetDegree] = useState<'XUAT_SAC' | 'GIOI' | 'KHA'>('GIOI');
  const [globalSimGrade, setGlobalSimGrade] = useState<number>(8.0);
  const [chartScale, setChartScale] = useState<'SCALE_4' | 'SCALE_10'>('SCALE_4');

  // Target GPA criteria according to UFM
  const targetMap = {
    XUAT_SAC: { name: 'Bằng Xuất Sắc', gpa10: 9.0, gpa4: 3.6 },
    GIOI: { name: 'Bằng Giỏi', gpa10: 8.0, gpa4: 3.2 },
    KHA: { name: 'Bằng Khá', gpa10: 7.0, gpa4: 2.5 },
  };

  const selectedTarget = targetMap[targetDegree];
  const requiredInfo = calculateRequiredAverage(courses, selectedTarget.gpa10);

  // Calculate simulated GPA across all courses using UFM standard
  const simulatedStats = calculateGpaStats(courses, true, gpaStandard);

  // Filter remaining / in-progress courses
  const pendingCourses = courses.filter((c) => c.status !== 'Đã học');

  const applyGlobalGrade = (grade: number) => {
    setGlobalSimGrade(grade);
    const updates: Record<string, number> = {};
    pendingCourses.forEach((c) => {
      updates[c.id] = grade;
    });
    onBatchSimulateScores(updates);
  };

  // Build cumulative trend data across all 10 semesters
  const trendData = useMemo(() => {
    const list: any[] = [];
    let accumulatedCourses: Course[] = [];

    SEMESTER_LIST.forEach((sem, index) => {
      // Courses in this specific semester
      const semCourses = courses.filter((c) => c.semester === sem.id);
      if (semCourses.length === 0) return;

      accumulatedCourses = [...accumulatedCourses, ...semCourses];

      // Calculate semester-only GPA
      let semWeighted4 = 0;
      let semWeighted10 = 0;
      let semCredits = 0;

      for (const c of semCourses) {
        let score = c.actualScore;
        if (score === null) {
          score = c.simulatedScore !== undefined && c.simulatedScore !== null ? c.simulatedScore : (c.targetScore ?? 8.0);
        }
        semWeighted4 += scoreToScale4(score, gpaStandard) * c.credits;
        semWeighted10 += score * c.credits;
        semCredits += c.credits;
      }

      const semGpa4 = semCredits > 0 ? Number((semWeighted4 / semCredits).toFixed(2)) : 0;
      const semGpa10 = semCredits > 0 ? Number((semWeighted10 / semCredits).toFixed(2)) : 0;

      // Calculate cumulative GPA up to this semester
      let cumWeighted4 = 0;
      let cumWeighted10 = 0;
      let cumCredits = 0;

      for (const c of accumulatedCourses) {
        let score = c.actualScore;
        if (score === null) {
          score = c.simulatedScore !== undefined && c.simulatedScore !== null ? c.simulatedScore : (c.targetScore ?? 8.0);
        }
        cumWeighted4 += scoreToScale4(score, gpaStandard) * c.credits;
        cumWeighted10 += score * c.credits;
        cumCredits += c.credits;
      }

      const cumulativeGpa4 = cumCredits > 0 ? Number((cumWeighted4 / cumCredits).toFixed(2)) : 0;
      const cumulativeGpa10 = cumCredits > 0 ? Number((cumWeighted10 / cumCredits).toFixed(2)) : 0;

      const isCompleted = index < 3; // HK1, HK2, HK3
      const isCurrent = index === 3;  // HK4
      const statusLabel = isCompleted ? 'Đã hoàn thành' : isCurrent ? 'Đang học' : 'Dự báo';

      list.push({
        semesterId: sem.id,
        shortName: `HK ${sem.semesterNum}`,
        fullName: sem.title,
        statusLabel,
        isCompleted,
        isCurrent,
        isFuture: !isCompleted && !isCurrent,
        semesterGpa4: semGpa4,
        semesterGpa10: semGpa10,
        cumulativeGpa4,
        cumulativeGpa10,
        credits: semCredits,
        cumCredits,
        rank: getRankFromGpa4(cumulativeGpa4),
      });
    });

    return list;
  }, [courses, gpaStandard]);

  // Custom chart tooltip
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900 text-white p-3.5 rounded-xl border border-slate-700 shadow-xl text-xs space-y-1.5 min-w-[200px]">
          <div className="flex items-center justify-between pb-1.5 border-b border-slate-700">
            <span className="font-bold text-sm text-indigo-300">{data.fullName}</span>
            <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
              data.isCompleted 
                ? 'bg-emerald-500/20 text-emerald-300' 
                : data.isCurrent 
                ? 'bg-amber-500/20 text-amber-300' 
                : 'bg-indigo-500/20 text-indigo-300'
            }`}>
              {data.statusLabel}
            </span>
          </div>

          <div className="space-y-1 pt-1">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">GPA Tích Lũy ({gpaStandard}):</span>
              <span className="font-extrabold text-amber-400 text-sm">
                {chartScale === 'SCALE_4' ? `${data.cumulativeGpa4} / 4.0` : `${data.cumulativeGpa10} / 10`}
              </span>
            </div>

            <div className="flex items-center justify-between text-slate-300">
              <span className="text-slate-400">GPA Kỳ này:</span>
              <span className="font-semibold text-white">
                {chartScale === 'SCALE_4' ? `${data.semesterGpa4} / 4.0` : `${data.semesterGpa10} / 10`}
              </span>
            </div>

            <div className="flex items-center justify-between text-slate-300">
              <span className="text-slate-400">Tín chỉ tích lũy:</span>
              <span className="font-medium text-white">{data.cumCredits} TC</span>
            </div>

            <div className="flex items-center justify-between pt-1 border-t border-slate-800 text-[11px]">
              <span className="text-slate-400">Xếp hạng đạt được:</span>
              <span className="font-bold text-emerald-400">{data.rank}</span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      
      {/* Target Setting & Required Average Hero Card */}
      <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 text-white rounded-2xl p-6 sm:p-8 shadow-md border border-indigo-900/60 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-6 border-b border-indigo-800/40">
            <div>
              <div className="flex items-center space-x-2 text-indigo-400 text-xs font-semibold uppercase tracking-wider mb-1">
                <School className="w-4 h-4 text-emerald-400" />
                <span>Quy Chế Tốt Nghiệp ĐH Tài Chính - Marketing (UFM)</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                Mô Phỏng GPA & Dự Báo Xếp Hạng Bằng
              </h2>
              <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl">
                Bạn đã tích lũy <strong className="text-white">{currentStats.completedCredits} TC</strong> với GPA UFM hiện tại <strong className="text-emerald-400">{currentStats.gpa10}/10 ({currentStats.gpa4}/4.0)</strong>. Còn lại <strong className="text-white">{currentStats.remainingCredits + currentStats.inProgressCredits} TC</strong> để bứt phá hạng bằng cử nhân!
              </p>
            </div>

            {/* Target Selector Buttons */}
            <div className="bg-slate-800/80 p-1.5 rounded-xl border border-slate-700/80 flex items-center gap-1 shrink-0">
              <button
                onClick={() => setTargetDegree('XUAT_SAC')}
                className={`px-3 py-2 rounded-lg text-xs font-bold transition-all ${
                  targetDegree === 'XUAT_SAC'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                Bằng Xuất Sắc (≥3.6)
              </button>
              <button
                onClick={() => setTargetDegree('GIOI')}
                className={`px-3 py-2 rounded-lg text-xs font-bold transition-all ${
                  targetDegree === 'GIOI'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                Bằng Giỏi (≥3.2)
              </button>
              <button
                onClick={() => setTargetDegree('KHA')}
                className={`px-3 py-2 rounded-lg text-xs font-bold transition-all ${
                  targetDegree === 'KHA'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                Bằng Khá (≥2.5)
              </button>
            </div>
          </div>

          {/* Target Analysis Results */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6">
            
            {/* Box 1: Required Score */}
            <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-700/70">
              <span className="text-xs text-indigo-300 font-semibold uppercase tracking-wider block">
                Điểm TB Cần Đạt ({selectedTarget.name})
              </span>
              <div className="mt-2 flex items-baseline space-x-2">
                <span className="text-4xl font-extrabold text-white tracking-tight">
                  {requiredInfo.requiredAverage !== null ? requiredInfo.requiredAverage : '—'}
                </span>
                <span className="text-sm text-slate-400">/ 10 điểm</span>
              </div>
              <div className="mt-2 text-xs">
                {requiredInfo.isAchievable ? (
                  <span className="text-emerald-400 flex items-center font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                    Rất khả thi! Duy trì mức này cho 99 tín chỉ còn lại.
                  </span>
                ) : (
                  <span className="text-rose-400 flex items-center font-medium">
                    <AlertCircle className="w-3.5 h-3.5 mr-1" />
                    Đòi hỏi &gt; 10.0 (Vượt ngưỡng tối đa).
                  </span>
                )}
              </div>
            </div>

            {/* Box 2: Simulated Overall GPA with UFM rules */}
            <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-700/70">
              <span className="text-xs text-amber-300 font-semibold uppercase tracking-wider block">
                GPA Toàn Khóa Dự Kiến (Chuẩn UFM)
              </span>
              <div className="mt-2 flex items-baseline space-x-2">
                <span className="text-4xl font-extrabold text-amber-400 tracking-tight">
                  {simulatedStats.gpa10}
                </span>
                <span className="text-sm text-slate-400">/ 10</span>
                <span className="text-base font-bold text-white bg-slate-700 px-2 py-0.5 rounded">
                  {simulatedStats.gpa4} / 4.0
                </span>
              </div>
              <div className="mt-2 text-xs text-slate-300">
                Xếp loại UFM: <strong className="text-white font-bold">{simulatedStats.rank}</strong> (Điểm chữ: {simulatedStats.letterGrade})
              </div>
            </div>

            {/* Box 3: Quick Scenarios */}
            <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-700/70 flex flex-col justify-between">
              <div>
                <span className="text-xs text-slate-300 font-semibold uppercase tracking-wider block mb-2">
                  Kịch Bản Nhanh (UFM Quy Đổi)
                </span>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    onClick={() => applyGlobalGrade(9.0)}
                    className="px-2.5 py-1 text-xs bg-slate-700 hover:bg-slate-600 text-white rounded font-medium transition-colors"
                  >
                    Toàn 9.0 (A+ 4.0)
                  </button>
                  <button
                    onClick={() => applyGlobalGrade(8.5)}
                    className="px-2.5 py-1 text-xs bg-slate-700 hover:bg-slate-600 text-white rounded font-medium transition-colors"
                  >
                    Toàn 8.5 (A 3.8)
                  </button>
                  <button
                    onClick={() => applyGlobalGrade(8.0)}
                    className="px-2.5 py-1 text-xs bg-slate-700 hover:bg-slate-600 text-white rounded font-medium transition-colors"
                  >
                    Toàn 8.0 (B+ 3.5)
                  </button>
                  <button
                    onClick={() => applyGlobalGrade(7.5)}
                    className="px-2.5 py-1 text-xs bg-slate-700 hover:bg-slate-600 text-white rounded font-medium transition-colors"
                  >
                    Toàn 7.5 (B 3.0)
                  </button>
                </div>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-700/60 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">Xóa các điểm giả định</span>
                <button
                  onClick={onResetSimulation}
                  className="text-xs text-rose-300 hover:text-rose-200 flex items-center space-x-1"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Khôi phục</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* NEW: Recharts Line Chart Component for GPA Trend */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-4 border-b border-slate-100 gap-3">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight flex items-center space-x-2">
                <span>Biểu Đồ Xu Hướng GPA Tích Lũy Dự Báo (10 Học Kỳ)</span>
                <span className="text-[10px] font-bold bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded border border-indigo-100">
                  {gpaStandard}
                </span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Đường nét liền thể hiện GPA tích lũy toàn khóa; đường đứt nét thể hiện GPA riêng của từng kỳ.
              </p>
            </div>
          </div>

          {/* Scale switch controls */}
          <div className="flex items-center space-x-1 bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs font-semibold self-start sm:self-auto">
            <button
              onClick={() => setChartScale('SCALE_4')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                chartScale === 'SCALE_4'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Thang Điểm 4 UFM
            </button>
            <button
              onClick={() => setChartScale('SCALE_10')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                chartScale === 'SCALE_10'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Thang Điểm 10
            </button>
          </div>
        </div>

        {/* Chart View */}
        <div className="mt-5 w-full h-[320px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={trendData}
              margin={{ top: 15, right: 30, left: -10, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              
              <XAxis 
                dataKey="shortName" 
                stroke="#64748b" 
                tick={{ fontSize: 11, fontWeight: 500 }} 
                tickMargin={8} 
              />
              
              <YAxis 
                domain={chartScale === 'SCALE_4' ? [2.0, 4.0] : [5.0, 10.0]} 
                ticks={chartScale === 'SCALE_4' ? [2.0, 2.5, 3.0, 3.2, 3.5, 3.6, 4.0] : [5.0, 6.0, 7.0, 8.0, 9.0, 10.0]}
                stroke="#64748b" 
                tick={{ fontSize: 11 }} 
              />
              
              <Tooltip content={<CustomTooltip />} />
              
              {/* Reference threshold lines for UFM graduation honors */}
              {chartScale === 'SCALE_4' ? (
                <>
                  <ReferenceLine 
                    y={3.6} 
                    stroke="#f59e0b" 
                    strokeDasharray="4 4" 
                    label={{ 
                      value: 'Chuẩn Xuất Sắc (3.6)', 
                      position: 'insideTopRight', 
                      fill: '#d97706', 
                      fontSize: 10, 
                      fontWeight: 700 
                    }} 
                  />
                  <ReferenceLine 
                    y={3.2} 
                    stroke="#6366f1" 
                    strokeDasharray="4 4" 
                    label={{ 
                      value: 'Chuẩn Bằng Giỏi (3.2)', 
                      position: 'insideTopRight', 
                      fill: '#4f46e5', 
                      fontSize: 10, 
                      fontWeight: 700 
                    }} 
                  />
                </>
              ) : (
                <>
                  <ReferenceLine 
                    y={9.0} 
                    stroke="#f59e0b" 
                    strokeDasharray="4 4" 
                    label={{ 
                      value: 'Chuẩn Xuất Sắc (9.0)', 
                      position: 'insideTopRight', 
                      fill: '#d97706', 
                      fontSize: 10, 
                      fontWeight: 700 
                    }} 
                  />
                  <ReferenceLine 
                    y={8.0} 
                    stroke="#6366f1" 
                    strokeDasharray="4 4" 
                    label={{ 
                      value: 'Chuẩn Bằng Giỏi (8.0)', 
                      position: 'insideTopRight', 
                      fill: '#4f46e5', 
                      fontSize: 10, 
                      fontWeight: 700 
                    }} 
                  />
                </>
              )}

              {/* Cumulative GPA Line (Main) */}
              <Line
                type="monotone"
                dataKey={chartScale === 'SCALE_4' ? 'cumulativeGpa4' : 'cumulativeGpa10'}
                name="GPA Tích Lũy Dự Báo"
                stroke="#4f46e5"
                strokeWidth={3}
                dot={{ r: 4, stroke: '#4f46e5', strokeWidth: 2, fill: '#ffffff' }}
                activeDot={{ r: 6, fill: '#4f46e5', stroke: '#ffffff', strokeWidth: 2 }}
              />

              {/* Semester GPA Line (Dashed) */}
              <Line
                type="monotone"
                dataKey={chartScale === 'SCALE_4' ? 'semesterGpa4' : 'semesterGpa10'}
                name="GPA Riêng Học Kỳ Đó"
                stroke="#94a3b8"
                strokeWidth={1.5}
                strokeDasharray="4 4"
                dot={{ r: 3, fill: '#94a3b8' }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Chart Summary Badges & Legend */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1.5">
              <span className="w-3 h-1 bg-indigo-600 rounded-full inline-block" />
              <span className="font-semibold text-slate-800">GPA Tích Lũy</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="w-3 h-1 bg-slate-400 rounded-full inline-block border-dashed" />
              <span className="text-slate-500">GPA Từng Học Kỳ</span>
            </div>
          </div>

          <div className="flex items-center space-x-2 text-[11px] text-slate-500">
            <span>HK1 - HK3: Thực tế</span>
            <span className="text-slate-300">·</span>
            <span className="text-amber-600 font-semibold">HK4: Đang học</span>
            <span className="text-slate-300">·</span>
            <span className="text-indigo-600 font-semibold">HK5 - HK10: Dự báo giả định</span>
          </div>
        </div>
      </div>

      {/* Course-by-Course Simulated Grade Editor */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-4 border-b border-slate-100 gap-2">
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">
              Tùy Chỉnh Điểm Giả Định Cho Từng Học Phần (34 Môn Còn Lại)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Thay đổi thanh trượt điểm để thấy ngay đồ thị xu hướng và GPA toàn khóa thay đổi trực tiếp.
            </p>
          </div>

          <div className="flex items-center space-x-2 text-xs text-slate-500">
            <span>Khóa luận tốt nghiệp có trọng số tới <strong className="text-indigo-600">6 Tín chỉ</strong>!</span>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {pendingCourses.map((c) => {
            const currentSim = c.simulatedScore !== undefined ? c.simulatedScore : (c.targetScore ?? 8.0);

            return (
              <div
                key={c.id}
                className="p-3 rounded-lg border border-slate-200 hover:border-indigo-300 bg-slate-50/50 hover:bg-white transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                    <span className="font-semibold text-slate-700">{c.semester}</span>
                    <span>{c.credits} TC · {c.language === 'Tiếng Anh' ? 'Tiếng Anh' : 'Tiếng Việt'}</span>
                  </div>

                  <h4 className="font-bold text-xs text-slate-900 leading-snug line-clamp-1" title={c.name}>
                    {c.name}
                  </h4>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-200/70 flex items-center justify-between gap-3">
                  <div className="text-[11px] text-slate-600 font-medium">
                    <span>Điểm: </span>
                    {currentSim !== null && (
                      <span className="font-bold text-indigo-600 font-mono">
                        ({scoreToLetter(currentSim, gpaStandard)} - {scoreToScale4(currentSim, gpaStandard)}/4)
                      </span>
                    )}
                  </div>

                  <div className="flex items-center space-x-2">
                    <input
                      type="range"
                      min="4.0"
                      max="10.0"
                      step="0.1"
                      value={currentSim ?? 8.0}
                      onChange={(e) => onUpdateCourseSimulatedScore(c.id, parseFloat(e.target.value))}
                      className="w-24 accent-indigo-600 cursor-pointer h-1.5"
                    />

                    <input
                      type="number"
                      min="0"
                      max="10"
                      step="0.1"
                      value={currentSim ?? ''}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        onUpdateCourseSimulatedScore(c.id, isNaN(val) ? null : Math.min(10, Math.max(0, val)));
                      }}
                      className="w-14 px-1.5 py-1 text-xs font-bold text-center bg-white border border-slate-300 rounded focus:border-indigo-600 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
