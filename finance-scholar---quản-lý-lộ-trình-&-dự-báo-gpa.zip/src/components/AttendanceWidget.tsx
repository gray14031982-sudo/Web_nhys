import React from 'react';
import { Clock, Plus, Minus, AlertTriangle, CheckCircle2, ShieldCheck } from 'lucide-react';
import { Course } from '../types/curriculum';

interface AttendanceWidgetProps {
  currentCourses: Course[];
  onUpdateAttendance: (courseId: string, delta: number) => void;
}

export const AttendanceWidget: React.FC<AttendanceWidgetProps> = ({
  currentCourses,
  onUpdateAttendance,
}) => {
  if (currentCourses.length === 0) return null;

  return (
    <div className="bg-white rounded-xl border border-amber-200/80 p-4 mb-6 shadow-xs bg-gradient-to-r from-amber-50/30 via-white to-amber-50/10">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-3 mb-3 border-b border-amber-100 gap-2">
        <div className="flex items-center space-x-2">
          <Clock className="w-4 h-4 text-amber-600" />
          <h3 className="text-sm font-bold text-slate-900 tracking-tight">
            Điểm Danh Chuyên Cần Nhanh · Học Kỳ 4 (Hiện Tại)
          </h3>
          <span className="text-[11px] text-slate-400">· Quy định: Không vắng quá 20% tổng số buổi</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {currentCourses.map((c) => {
          const percent = c.totalSessions > 0 ? Math.round((c.attendedSessions / c.totalSessions) * 100) : 0;
          const maxAbsences = Math.floor(c.totalSessions * 0.2); // max 20% allowed
          const remainingSessions = c.totalSessions - c.attendedSessions;

          return (
            <div
              key={c.id}
              className="p-3 bg-white rounded-lg border border-slate-200 hover:border-amber-300 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-1 mb-1">
                  <h4 className="font-bold text-xs text-slate-900 leading-snug truncate" title={c.name}>
                    {c.name}
                  </h4>
                  <span className="text-[10px] font-bold text-slate-500 shrink-0">
                    {c.credits} TC
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500 mt-2">
                  <span>Đã học: <strong className="text-slate-900">{c.attendedSessions} / {c.totalSessions}</strong> buổi</span>
                  <span className="font-bold text-amber-600">{percent}%</span>
                </div>

                <div className="w-full bg-slate-100 h-1.5 rounded-full mt-1.5 overflow-hidden">
                  <div
                    className="bg-amber-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${percent}%` }}
                  />
                </div>
              </div>

              <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[10px] text-slate-400">
                  Còn {remainingSessions} buổi
                </span>

                <div className="flex items-center space-x-1.5">
                  <button
                    onClick={() => onUpdateAttendance(c.id, -1)}
                    disabled={c.attendedSessions <= 0}
                    className="w-6 h-6 rounded flex items-center justify-center bg-slate-100 hover:bg-slate-200 text-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                    title="Giảm 1 buổi"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => onUpdateAttendance(c.id, 1)}
                    disabled={c.attendedSessions >= c.totalSessions}
                    className="px-2 py-0.5 rounded text-xs bg-amber-500 hover:bg-amber-600 text-white font-bold disabled:opacity-30 disabled:cursor-not-allowed transition-colors flex items-center space-x-1 shadow-xs"
                    title="Điểm danh đã học 1 buổi"
                  >
                    <Plus className="w-3 h-3" />
                    <span>+1 Buổi</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
