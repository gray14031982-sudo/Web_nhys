import React, { useState, useEffect, useMemo } from 'react';
import { Course, CourseDifficulty, CourseLanguage, CourseStatus, GpaStandard, NotificationItem, SemesterId, SemesterInfo } from './types/curriculum';
import { INITIAL_COURSES, SEMESTER_LIST } from './data/initialCourses';
import { calculateGpaStats, exportCoursesToCsv } from './utils/gradeCalculations';
import { Header } from './components/Header';
import { DashboardStats } from './components/DashboardStats';
import { SemesterTimeline } from './components/SemesterTimeline';
import { CourseFilters } from './components/CourseFilters';
import { CourseCard } from './components/CourseCard';
import { CourseTable } from './components/CourseTable';
import { CourseModal } from './components/CourseModal';
import { GpaSimulator } from './components/GpaSimulator';
import { AiAdvisor } from './components/AiAdvisor';
import { AttendanceWidget } from './components/AttendanceWidget';
import { SettingsView } from './components/SettingsView';
import { NotificationCenter } from './components/NotificationCenter';
import { ToastContainer, ToastMessage } from './components/Toast';

const STORAGE_KEY_COURSES = 'ufm_finance_scholar_courses';
const STORAGE_KEY_SEMESTERS = 'ufm_finance_scholar_semesters';
const STORAGE_KEY_STANDARD = 'ufm_finance_scholar_standard';
const STORAGE_KEY_NOTIFS = 'ufm_finance_scholar_notifications';

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif_ufm_scale',
    type: 'success',
    title: 'Chuẩn Thang Điểm UFM Chính Thức',
    message: 'Hệ thống đã áp dụng chuẩn GPA Đại học Tài chính - Marketing (QĐ 3279 & 1086): A+ (4.0 từ 9.0), A (3.8 từ 8.5), B+ (3.5), B (3.0), C+ (2.5 từ 6.0).',
    time: 'Vừa xong',
    read: false,
    linkAction: 'settings',
  },
  {
    id: 'notif_attendance_alert',
    type: 'warning',
    title: 'Cảnh Báo Chuyên Cần Học Kỳ 4',
    message: 'Môn Tư tưởng Hồ Chí Minh mới học 2/10 buổi (tối đa vắng 2 buổi theo quy định 20% của UFM). Hãy chú ý điểm danh đầy đủ!',
    time: '1 giờ trước',
    read: false,
    linkAction: 'roadmap',
  },
  {
    id: 'notif_exam_strategy',
    type: 'info',
    title: 'Môn Trọng Tâm: Tài Chính Doanh Nghiệp (TA)',
    message: 'Môn học cốt lõi thi đề mở + tự luận bằng Tiếng Anh. Đã tích hợp nút mở nhanh tài liệu "TCDN1 = TA" trên thẻ môn học.',
    time: 'Hôm nay',
    read: false,
    linkAction: 'roadmap',
  },
  {
    id: 'notif_document_links',
    type: 'info',
    title: 'Tính Năng Mới: Mở Trực Tiếp Tài Liệu',
    message: 'Bạn có thể bấm trực tiếp vào tên tài liệu trên thẻ môn học hoặc bảng để mở Google Drive / liên kết học tập ngay lập tức.',
    time: 'Hôm nay',
    read: false,
  },
];

export default function App() {
  // Courses state
  const [courses, setCourses] = useState<Course[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_COURSES);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error('Failed to load courses', e);
    }
    return INITIAL_COURSES;
  });

  // Semesters state
  const [semesters, setSemesters] = useState<SemesterInfo[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SEMESTERS);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error('Failed to load semesters', e);
    }
    return SEMESTER_LIST;
  });

  // GPA standard (UFM default)
  const [gpaStandard, setGpaStandard] = useState<GpaStandard>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_STANDARD);
      if (saved === 'MOET' || saved === 'UFM') {
        return saved;
      }
    } catch (e) {
      console.error(e);
    }
    return 'UFM';
  });

  // Notifications state
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_NOTIFS);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error(e);
    }
    return INITIAL_NOTIFICATIONS;
  });

  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Navigation and filters
  const [activeTab, setActiveTab] = useState<'roadmap' | 'table' | 'simulator' | 'ai-advisor' | 'settings'>('roadmap');
  const [selectedSemester, setSelectedSemester] = useState<SemesterId | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<CourseStatus | 'ALL'>('ALL');
  const [difficultyFilter, setDifficultyFilter] = useState<CourseDifficulty | 'ALL'>('ALL');
  const [languageFilter, setLanguageFilter] = useState<CourseLanguage | 'ALL'>('ALL');
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');

  // Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);

  // Persistence effects
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_COURSES, JSON.stringify(courses));
    } catch (e) {
      console.error(e);
    }
  }, [courses]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SEMESTERS, JSON.stringify(semesters));
    } catch (e) {
      console.error(e);
    }
  }, [semesters]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_STANDARD, gpaStandard);
    } catch (e) {
      console.error(e);
    }
  }, [gpaStandard]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_NOTIFS, JSON.stringify(notifications));
    } catch (e) {
      console.error(e);
    }
  }, [notifications]);

  // Toast helper
  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = `toast_${Date.now()}_${Math.random()}`;
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  };

  const handleDismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // GPA stats based on active standard (UFM)
  const stats = useMemo(() => calculateGpaStats(courses, false, gpaStandard), [courses, gpaStandard]);

  // Filtered courses
  const filteredCourses = useMemo(() => {
    return courses.filter((c) => {
      if (selectedSemester !== 'ALL' && c.semester !== selectedSemester) return false;
      if (statusFilter !== 'ALL' && c.status !== statusFilter) return false;
      if (difficultyFilter !== 'ALL' && c.difficulty !== difficultyFilter) return false;
      if (languageFilter !== 'ALL' && c.language !== languageFilter) return false;
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase().trim();
        return (
          c.name.toLowerCase().includes(query) ||
          c.notes.toLowerCase().includes(query) ||
          c.documents.toLowerCase().includes(query) ||
          c.examFormat.toLowerCase().includes(query) ||
          c.semester.toLowerCase().includes(query)
        );
      }
      return true;
    });
  }, [courses, selectedSemester, statusFilter, difficultyFilter, languageFilter, searchQuery]);

  // Current semester courses
  const currentSemesterCourses = useMemo(() => {
    return courses.filter((c) => c.status === 'Đang học');
  }, [courses]);

  // Handlers
  const handleOpenAddModal = () => {
    setEditingCourse(null);
    setIsModalOpen(true);
  };

  const handleEditCourse = (course: Course) => {
    setEditingCourse(course);
    setIsModalOpen(true);
  };

  const handleSaveCourse = (savedCourse: Course) => {
    setCourses((prev) => {
      const exists = prev.some((c) => c.id === savedCourse.id);
      if (exists) {
        return prev.map((c) => (c.id === savedCourse.id ? savedCourse : c));
      }
      return [savedCourse, ...prev];
    });
    showToast(`Đã lưu học phần "${savedCourse.name}" thành công!`, 'success');
  };

  const handleDeleteCourse = (courseId: string) => {
    const courseToDelete = courses.find((c) => c.id === courseId);
    if (window.confirm(`Bạn có chắc chắn muốn xóa môn "${courseToDelete?.name || ''}" khỏi danh sách?`)) {
      setCourses((prev) => prev.filter((c) => c.id !== courseId));
      showToast('Đã xóa môn học khỏi danh sách.', 'info');
    }
  };

  const handleUpdateAttendance = (courseId: string, delta: number) => {
    setCourses((prev) =>
      prev.map((c) => {
        if (c.id === courseId) {
          const nextVal = Math.max(0, Math.min(c.totalSessions, c.attendedSessions + delta));
          return { ...c, attendedSessions: nextVal };
        }
        return c;
      })
    );
  };

  const handleUpdateSimulatedScore = (courseId: string, score: number | null) => {
    setCourses((prev) =>
      prev.map((c) => (c.id === courseId ? { ...c, simulatedScore: score } : c))
    );
  };

  const handleBatchSimulateScores = (scores: Record<string, number | null>) => {
    setCourses((prev) =>
      prev.map((c) => {
        if (scores[c.id] !== undefined) {
          return { ...c, simulatedScore: scores[c.id] };
        }
        return c;
      })
    );
  };

  const handleResetSimulation = () => {
    setCourses((prev) =>
      prev.map((c) => ({ ...c, simulatedScore: undefined }))
    );
    showToast('Đã đặt lại các điểm giả định.', 'info');
  };

  const handleExportCsv = () => {
    const csvContent = '\uFEFF' + exportCoursesToCsv(courses);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `UFM_Bang_Diem_TCNH_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Đã tải xuống file CSV chuẩn Excel!', 'success');
  };

  const handleResetOriginalData = () => {
    setCourses(INITIAL_COURSES);
    setSemesters(SEMESTER_LIST);
    setGpaStandard('UFM');
    localStorage.removeItem(STORAGE_KEY_COURSES);
    localStorage.removeItem(STORAGE_KEY_SEMESTERS);
    showToast('Đã khôi phục toàn bộ 47 môn học theo dữ liệu sheet UFM gốc.', 'success');
  };

  const handleAddSemester = (newSem: SemesterInfo) => {
    setSemesters((prev) => [...prev, newSem]);
  };

  const handleMarkAllNotifsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    showToast('Đã đánh dấu đã đọc tất cả thông báo.', 'info');
  };

  const handleClearNotifications = () => {
    setNotifications([]);
    showToast('Đã xóa tất cả thông báo.', 'info');
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 pb-16">
      
      {/* Header */}
      <Header
        stats={stats}
        gpaStandard={gpaStandard}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAddModal={handleOpenAddModal}
        onExportCsv={handleExportCsv}
        unreadNotificationsCount={unreadCount}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
      />

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        
        {/* KPI Dashboard */}
        <DashboardStats
          stats={stats}
          courses={courses}
          gpaStandard={gpaStandard}
          onOpenSimulator={() => setActiveTab('simulator')}
          onOpenSettings={() => setActiveTab('settings')}
        />

        {/* Tab 1: Roadmap & Course Cards */}
        {activeTab === 'roadmap' && (
          <div>
            {/* Quick Attendance Widget for HK4 */}
            <AttendanceWidget
              currentCourses={currentSemesterCourses}
              onUpdateAttendance={handleUpdateAttendance}
            />

            {/* Semester Timeline selector */}
            <SemesterTimeline
              courses={courses}
              semesters={semesters}
              selectedSemester={selectedSemester}
              gpaStandard={gpaStandard}
              onSelectSemester={setSelectedSemester}
            />

            {/* Filter controls */}
            <CourseFilters
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              statusFilter={statusFilter}
              setStatusFilter={setStatusFilter}
              difficultyFilter={difficultyFilter}
              setDifficultyFilter={setDifficultyFilter}
              languageFilter={languageFilter}
              setLanguageFilter={setLanguageFilter}
              viewMode={viewMode}
              setViewMode={setViewMode}
              totalFiltered={filteredCourses.length}
            />

            {/* Content Display: Cards or Table */}
            {viewMode === 'cards' ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredCourses.length === 0 ? (
                  <div className="col-span-full py-16 text-center bg-white rounded-xl border border-slate-200 text-slate-400">
                    Không tìm thấy môn học nào phù hợp với bộ lọc hiện tại.
                  </div>
                ) : (
                  filteredCourses.map((course) => (
                    <CourseCard
                      key={course.id}
                      course={course}
                      gpaStandard={gpaStandard}
                      onEdit={handleEditCourse}
                      onDelete={handleDeleteCourse}
                      onUpdateAttendance={handleUpdateAttendance}
                    />
                  ))
                )}
              </div>
            ) : (
              <CourseTable
                courses={filteredCourses}
                gpaStandard={gpaStandard}
                onEdit={handleEditCourse}
                onDelete={handleDeleteCourse}
                onUpdateAttendance={handleUpdateAttendance}
              />
            )}
          </div>
        )}

        {/* Tab 2: Full Table Sheet */}
        {activeTab === 'table' && (
          <div>
            <div className="mb-4 bg-white rounded-xl border border-slate-200 p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 shadow-xs">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Bảng Kê Chi Tiết Chương Trình Đào Tạo UFM
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Đồng bộ dữ liệu {courses.length} môn học theo mẫu Google Sheet. Nhấn trực tiếp vào tài liệu để mở liên kết.
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={handleExportCsv}
                  className="px-3 py-1.5 text-xs font-semibold bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors shadow-xs"
                >
                  Tải Về File CSV (Excel)
                </button>
              </div>
            </div>

            <CourseFilters
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              statusFilter={statusFilter}
              setStatusFilter={setStatusFilter}
              difficultyFilter={difficultyFilter}
              setDifficultyFilter={setDifficultyFilter}
              languageFilter={languageFilter}
              setLanguageFilter={setLanguageFilter}
              viewMode="table"
              setViewMode={() => {}}
              totalFiltered={filteredCourses.length}
            />

            <CourseTable
              courses={filteredCourses}
              gpaStandard={gpaStandard}
              onEdit={handleEditCourse}
              onDelete={handleDeleteCourse}
              onUpdateAttendance={handleUpdateAttendance}
            />
          </div>
        )}

        {/* Tab 3: GPA Simulator */}
        {activeTab === 'simulator' && (
          <GpaSimulator
            courses={courses}
            currentStats={stats}
            gpaStandard={gpaStandard}
            onUpdateCourseSimulatedScore={handleUpdateSimulatedScore}
            onBatchSimulateScores={handleBatchSimulateScores}
            onResetSimulation={handleResetSimulation}
          />
        )}

        {/* Tab 4: AI Advisor */}
        {activeTab === 'ai-advisor' && (
          <AiAdvisor courses={courses} stats={stats} />
        )}

        {/* Tab 5: Settings & Data Management */}
        {activeTab === 'settings' && (
          <SettingsView
            gpaStandard={gpaStandard}
            onSetGpaStandard={setGpaStandard}
            semesters={semesters}
            onAddSemester={handleAddSemester}
            onSetCurrentSemester={(id) => {
              setSemesters((prev) =>
                prev.map((s) => ({ ...s, isCurrent: s.id === id }))
              );
              showToast(`Đã chọn "${id}" làm học kỳ hiện tại!`, 'info');
            }}
            courses={courses}
            onImportCourses={(imported) => {
              setCourses(imported);
              showToast(`Đã nhập thành công ${imported.length} môn học!`, 'success');
            }}
            onResetOriginalData={handleResetOriginalData}
            onShowToast={showToast}
          />
        )}

      </main>

      {/* Course Edit/Add Modal */}
      <CourseModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveCourse}
        initialCourse={editingCourse}
        availableSemesters={semesters}
      />

      {/* Notifications Popover Modal */}
      <NotificationCenter
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={notifications}
        onMarkAllAsRead={handleMarkAllNotifsAsRead}
        onClearNotifications={handleClearNotifications}
        onNavigateTab={(tab) => setActiveTab(tab)}
      />

      {/* Floating Toast Alerts */}
      <ToastContainer
        toasts={toasts}
        onDismiss={handleDismissToast}
      />

    </div>
  );
}
