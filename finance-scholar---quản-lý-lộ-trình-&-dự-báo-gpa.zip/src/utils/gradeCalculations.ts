import { Course, GpaStandard, GpaStats, SemesterId } from '../types/curriculum';

/**
 * UFM (Trường Đại học Tài chính - Marketing) Thang điểm chuẩn:
 * Quyết định 3279/QĐ-ĐHTCM và Quyết định 1086/QĐ-ĐHTCM
 * 9.0 - 10.0 -> A+ (4.0) (Xuất sắc)
 * 8.5 - 8.9  -> A  (3.8) (Giỏi)
 * 8.0 - 8.4  -> B+ (3.5) (Khá)
 * 7.0 - 7.9  -> B  (3.0) (Khá)
 * 6.0 - 6.9  -> C+ (2.5) (Trung bình)
 * 5.5 - 5.9  -> C  (2.0) (Trung bình)
 * 5.0 - 5.4  -> D+ (1.5) (Yếu)
 * 4.0 - 4.9  -> D  (1.0) (Yếu)
 * 0.0 - 3.9  -> F  (0.0) (Kém - Chưa đạt)
 */
export function scoreToScale4(score: number, standard: GpaStandard = 'UFM'): number {
  if (standard === 'UFM') {
    if (score >= 9.0) return 4.0;
    if (score >= 8.5) return 3.8;
    if (score >= 8.0) return 3.5;
    if (score >= 7.0) return 3.0;
    if (score >= 6.0) return 2.5;
    if (score >= 5.5) return 2.0;
    if (score >= 5.0) return 1.5;
    if (score >= 4.0) return 1.0;
    return 0.0;
  }

  // MOET standard
  if (score >= 8.5) return 4.0;
  if (score >= 8.0) return 3.5;
  if (score >= 7.0) return 3.0;
  if (score >= 6.5) return 2.5;
  if (score >= 5.5) return 2.0;
  if (score >= 5.0) return 1.5;
  if (score >= 4.0) return 1.0;
  return 0.0;
}

export function scoreToLetter(score: number, standard: GpaStandard = 'UFM'): string {
  if (standard === 'UFM') {
    if (score >= 9.0) return 'A+';
    if (score >= 8.5) return 'A';
    if (score >= 8.0) return 'B+';
    if (score >= 7.0) return 'B';
    if (score >= 6.0) return 'C+';
    if (score >= 5.5) return 'C';
    if (score >= 5.0) return 'D+';
    if (score >= 4.0) return 'D';
    return 'F';
  }

  if (score >= 8.5) return 'A';
  if (score >= 8.0) return 'B+';
  if (score >= 7.0) return 'B';
  if (score >= 6.5) return 'C+';
  if (score >= 5.5) return 'C';
  if (score >= 5.0) return 'D+';
  if (score >= 4.0) return 'D';
  return 'F';
}

export function getRankFromGpa4(gpa4: number): 'Xuất sắc' | 'Giỏi' | 'Khá' | 'Trung bình' | 'Yếu' {
  if (gpa4 >= 3.6) return 'Xuất sắc';
  if (gpa4 >= 3.2) return 'Giỏi';
  if (gpa4 >= 2.5) return 'Khá';
  if (gpa4 >= 2.0) return 'Trung bình';
  return 'Yếu';
}

export function calculateGpaStats(
  courses: Course[],
  includeSimulated: boolean = false,
  standard: GpaStandard = 'UFM'
): GpaStats {
  let completedCredits = 0;
  let inProgressCredits = 0;
  let remainingCredits = 0;
  let totalCredits = 0;
  let totalWeightedScore10 = 0;
  let totalWeightedScore4 = 0;
  let scoredCredits = 0;
  let completedCount = 0;

  for (const c of courses) {
    totalCredits += c.credits;
    if (c.status === 'Đã học') {
      completedCredits += c.credits;
      completedCount++;
      if (c.actualScore !== null) {
        totalWeightedScore10 += c.actualScore * c.credits;
        totalWeightedScore4 += scoreToScale4(c.actualScore, standard) * c.credits;
        scoredCredits += c.credits;
      }
    } else if (c.status === 'Đang học') {
      inProgressCredits += c.credits;
      if (includeSimulated && c.simulatedScore !== null && c.simulatedScore !== undefined) {
        totalWeightedScore10 += c.simulatedScore * c.credits;
        totalWeightedScore4 += scoreToScale4(c.simulatedScore, standard) * c.credits;
        scoredCredits += c.credits;
      }
    } else {
      remainingCredits += c.credits;
      if (includeSimulated && c.simulatedScore !== null && c.simulatedScore !== undefined) {
        totalWeightedScore10 += c.simulatedScore * c.credits;
        totalWeightedScore4 += scoreToScale4(c.simulatedScore, standard) * c.credits;
        scoredCredits += c.credits;
      }
    }
  }

  const gpa10 = scoredCredits > 0 ? Number((totalWeightedScore10 / scoredCredits).toFixed(2)) : 0;
  const gpa4 = scoredCredits > 0 ? Number((totalWeightedScore4 / scoredCredits).toFixed(2)) : 0;

  return {
    totalCredits,
    completedCredits,
    inProgressCredits,
    remainingCredits: totalCredits - completedCredits - inProgressCredits,
    gpa10,
    gpa4,
    letterGrade: scoreToLetter(gpa10, standard),
    rank: getRankFromGpa4(gpa4),
    coursesCompletedCount: completedCount,
    coursesTotalCount: courses.length,
  };
}

export function calculateSemesterSummary(
  courses: Course[], 
  semesterId: SemesterId,
  standard: GpaStandard = 'UFM'
) {
  const semCourses = courses.filter((c) => c.semester === semesterId);
  const totalCredits = semCourses.reduce((sum, c) => sum + c.credits, 0);
  
  let scoredCredits = 0;
  let weightedScore10 = 0;
  let weightedScore4 = 0;
  let completedSessions = 0;
  let totalSessions = 0;

  for (const c of semCourses) {
    totalSessions += c.totalSessions;
    completedSessions += c.attendedSessions;

    if (c.actualScore !== null) {
      scoredCredits += c.credits;
      weightedScore10 += c.actualScore * c.credits;
      weightedScore4 += scoreToScale4(c.actualScore, standard) * c.credits;
    }
  }

  return {
    totalCredits,
    courseCount: semCourses.length,
    gpa10: scoredCredits > 0 ? Number((weightedScore10 / scoredCredits).toFixed(2)) : null,
    gpa4: scoredCredits > 0 ? Number((weightedScore4 / scoredCredits).toFixed(2)) : null,
    sessionProgress: totalSessions > 0 ? Math.round((completedSessions / totalSessions) * 100) : 0,
    completedSessions,
    totalSessions,
  };
}

export function calculateRequiredAverage(
  courses: Course[],
  targetFinalGpa10: number
): { requiredAverage: number | null; isAchievable: boolean } {
  const completed = courses.filter((c) => c.status === 'Đã học' && c.actualScore !== null);
  const currentWeightedSum = completed.reduce((sum, c) => sum + (c.actualScore || 0) * c.credits, 0);
  const currentCredits = completed.reduce((sum, c) => sum + c.credits, 0);

  const totalCredits = courses.reduce((sum, c) => sum + c.credits, 0);
  const remainingCredits = totalCredits - currentCredits;

  if (remainingCredits <= 0) {
    return { requiredAverage: null, isAchievable: false };
  }

  const targetTotalSum = targetFinalGpa10 * totalCredits;
  const neededSum = targetTotalSum - currentWeightedSum;
  const requiredAverage = Number((neededSum / remainingCredits).toFixed(2));

  return {
    requiredAverage,
    isAchievable: requiredAverage <= 10.0,
  };
}

export function exportCoursesToCsv(courses: Course[]): string {
  const headers = [
    'Năm - Học kì',
    'Tên học phần',
    'Số tín chỉ',
    'Ngôn ngữ giảng dạy',
    'Tổng số buổi',
    'Số buổi đã học',
    'Mục tiêu',
    'Điểm thực tế',
    'Tiến độ',
    'Trạng thái',
    'Hình thức thi',
    'Mức độ khó',
    'Tài liệu',
    'Link tài liệu',
    'Ghi chú',
  ];

  const rows = courses.map((c) => {
    const progress = c.totalSessions > 0 ? `${((c.attendedSessions / c.totalSessions) * 100).toFixed(1)}%` : '0.0%';
    return [
      `"${c.semester}"`,
      `"${c.name}"`,
      c.credits,
      `"${c.language}"`,
      c.totalSessions,
      c.attendedSessions,
      c.targetScore !== null ? `"${c.targetScore.toString().replace('.', ',')}"` : '""',
      c.actualScore !== null ? `"${c.actualScore.toString().replace('.', ',')}"` : '""',
      `"${progress}"`,
      `"${c.status}"`,
      `"${c.examFormat}"`,
      `"${c.difficulty}"`,
      `"${c.documents}"`,
      `"${c.documentUrl || ''}"`,
      `"${c.notes}"`,
    ].join(',');
  });

  return [headers.join(','), ...rows].join('\n');
}
