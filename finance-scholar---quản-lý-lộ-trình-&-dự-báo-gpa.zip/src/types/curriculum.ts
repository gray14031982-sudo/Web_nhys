export type SemesterId = string;

export type CourseStatus = 'Đã học' | 'Đang học' | 'Chưa học';
export type CourseDifficulty = 'Dễ' | 'Trung bình' | 'Khó';
export type CourseLanguage = 'Tiếng Việt' | 'Tiếng Anh';
export type GpaStandard = 'UFM' | 'MOET';

export interface Course {
  id: string;
  semester: SemesterId;
  name: string;
  credits: number;
  language: CourseLanguage;
  totalSessions: number;
  attendedSessions: number;
  targetScore: number | null;
  actualScore: number | null;
  status: CourseStatus;
  examFormat: string;
  difficulty: CourseDifficulty;
  documents: string;
  documentUrl?: string;
  notes: string;
  // Simulation hypothetical score
  simulatedScore?: number | null;
}

export interface SemesterInfo {
  id: SemesterId;
  year: number;
  semesterNum: number;
  title: string;
  isCurrent?: boolean;
}

export interface GpaStats {
  totalCredits: number;
  completedCredits: number;
  inProgressCredits: number;
  remainingCredits: number;
  gpa10: number;
  gpa4: number;
  letterGrade: string;
  rank: 'Xuất sắc' | 'Giỏi' | 'Khá' | 'Trung bình' | 'Yếu';
  coursesCompletedCount: number;
  coursesTotalCount: number;
}

export interface NotificationItem {
  id: string;
  type: 'warning' | 'info' | 'success' | 'deadline';
  title: string;
  message: string;
  time: string;
  read?: boolean;
  linkAction?: string;
}

